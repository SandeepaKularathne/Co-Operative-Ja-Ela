-- MySQL dump 10.13  Distrib 8.0.30, for macos12 (x86_64)
--
-- Host: localhost    Database: cooperativejaela
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Electronics'),(2,'Furniture'),(3,'Clothing'),(4,'Food & Beverages'),(5,'Automotive'),(6,'Health & Beauty'),(7,'Sports & Outdoors'),(8,'Books'),(9,'Toys'),(10,'Home Appliances'),(11,'Jewelry'),(12,'Stationery'),(13,'Garden & Outdoor'),(14,'Pet Supplies'),(15,'Office Supplies'),(16,'Music Instruments'),(17,'Baby Products'),(18,'Groceries'),(19,'Footwear'),(20,'Bags & Luggage'),(21,'Home Decor'),(22,'Lighting'),(23,'Building Materials'),(24,'Tools & Hardware'),(25,'Cleaning Supplies'),(26,'Pharmaceuticals'),(27,'Cosmetics'),(28,'Safety & Security'),(29,'Craft Supplies'),(30,'Party Supplies');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `critem`
--

DROP TABLE IF EXISTS `critem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `critem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qty` decimal(6,2) DEFAULT NULL,
  `customerreturn_id` int NOT NULL,
  `Item_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_critem_customerreturn1_idx` (`customerreturn_id`),
  KEY `fk_critem_Item1_idx` (`Item_id`),
  CONSTRAINT `fk_critem_customerreturn1` FOREIGN KEY (`customerreturn_id`) REFERENCES `customerreturn` (`id`),
  CONSTRAINT `fk_critem_Item1` FOREIGN KEY (`Item_id`) REFERENCES `Item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `critem`
--

LOCK TABLES `critem` WRITE;
/*!40000 ALTER TABLE `critem` DISABLE KEYS */;
INSERT INTO `critem` VALUES (2,1.00,8,3),(3,1.00,9,1);
/*!40000 ALTER TABLE `critem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phonenumber` char(12) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `gender_id` int NOT NULL,
  `loyaltyprogram_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customer_gender1_idx` (`gender_id`),
  KEY `fk_customer_ loyaltyprogram1_idx` (`loyaltyprogram_id`),
  CONSTRAINT `fk_customer_ loyaltyprogram1` FOREIGN KEY (`loyaltyprogram_id`) REFERENCES `loyaltyprogram` (`id`),
  CONSTRAINT `fk_customer_gender1` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'John Deo','1985-07-19','john.doe@example.com','0771234567','Colombo','2024-07-10',1,3),(2,'Jane Smith','1990-03-22','jane.smith@example.com','0712345678','Kandy','2024-07-11',2,1),(3,'Michael Brown','1982-11-05','michael.brown@example.com','0723456789','Galle','2024-07-12',2,4),(4,'Emily Davis','1995-06-18','emily.davis@example.com','0754567890','Negombo','2024-07-12',1,5),(5,'David Wilson','1988-12-09','david.wilson@example.com','0745678901','Jaffna','2024-07-12',2,2),(6,'Emma White','1993-09-15','emma.white@example.com','0776789012','Colombo','2024-07-12',1,3),(7,'Daniel Harris','1980-05-23','daniel.harris@example.com','0717890123','Kandy','2024-07-12',1,4),(8,'Sophia Martinez','1992-02-14','sophia.martinez@example.com','0728901234','Galle','2024-07-12',2,5),(9,'Matthew Taylor','1987-07-30','matthew.taylor@example.com','0759012345','Negombo','2024-07-12',2,1),(10,'Olivia Anderson','1994-10-20','olivia.anderson@example.com','0740123456','Jaffna','2024-07-12',1,2),(11,'Joshua Thomas','1981-04-25','joshua.thomas@example.com','0771234568','Colombo','2024-07-12',2,3),(12,'Ava Jackson','1986-08-17','ava.jackson@example.com','0712345679','Kandy','2024-07-12',1,4),(13,'James White','1991-01-28','james.white@example.com','0723456780','Galle','2024-03-12',1,5),(14,'Mia Lee','1989-03-31','mia.lee@example.com','0754567891','Negombo','2024-07-12',2,1),(15,'Benjamin Scott','1993-07-22','benjamin.scott@example.com','0745678902','Jaffna','2024-04-12',2,2),(16,'Charlotte Green','1983-11-11','charlotte.green@example.com','0776789013','Colombo','2024-04-12',1,3),(17,'Henry Baker','1992-06-06','henry.baker@example.com','0717890124','Kandy','2024-06-12',2,4),(18,'Amelia Adams','1984-09-03','amelia.adams@example.com','0728901235','Galle','2024-06-12',1,5),(19,'Alexander Nelson','1990-12-27','alexander.nelson@example.com','0759012346','Negombo','2024-07-12',1,1),(20,'Isabella Wright','1987-05-14','isabella.wright@example.com','0740123457','Jaffna','2024-04-12',2,2),(21,'John Doe','1985-05-20','johndoe@example.com','123456789012','Colombo','2024-07-20',1,3),(22,'Jane Smith','1990-07-15','janesmith@example.com','098765432109','Galle','2023-08-10',2,4),(23,'Michael Brown','1975-03-22','michaelbrown@example.com','112233445566','Kandy','2024-03-05',2,2),(24,'Alice Johnson','1987-02-14','alicejohnson@example.com','123450987654','Colombo','2023-01-10',1,1),(25,'Bob Smith','1991-03-25','bobsmith@example.com','234561098765','Galle','2023-02-20',2,2),(26,'Carol White','1985-04-30','carolwhite@example.com','345672109876','Kandy','2023-03-15',1,3),(27,'David Brown','1978-05-22','davidbrown@example.com','456783210987','Matara','2023-04-10',1,4),(28,'Eve Davis','1980-06-18','evedavis@example.com','567894321098','Negombo','2023-05-05',2,5),(29,'Frank Harris','1992-07-21','frankharris@example.com','678905432109','Kurunegala','2023-06-25',1,1),(30,'Grace Martin','1984-08-19','gracemartin@example.com','789016543210','Jaffna','2023-07-15',1,2),(31,'Henry Thompson','1976-09-14','henrythompson@example.com','890127654321','Anuradhapura','2023-08-05',2,3),(32,'Ivy Garcia','1989-10-29','ivygarcia@example.com','901238765432','Trincomalee','2023-09-20',1,4),(33,'Jack Lee','1993-11-05','jacklee@example.com','012349876543','Ratnapura','2023-10-10',1,5),(34,'Kathy Walker','1982-12-17','kathywalker@example.com','123450987654','Batticaloa','2023-11-25',2,1),(35,'Liam Young','1995-01-23','liamyoung@example.com','234561098765','Kalutara','2023-12-30',2,2),(36,'Mia Allen','1990-02-12','miaallen@example.com','345672109876','Hambantota','2024-01-10',1,3),(37,'Noah King','1986-03-14','noahking@example.com','456783210987','Badulla','2024-02-20',2,4),(38,'Olivia Wright','1981-04-25','oliviawright@example.com','567894321098','Ampara','2024-03-15',2,5),(39,'Paul Scott','1988-05-30','paulscott@example.com','678905432109','Puttalam','2024-04-10',1,1),(40,'Quinn Lewis','1994-06-21','quinnlewis@example.com','789016543210','Nuwara Eliya','2024-05-05',2,2),(41,'Ryan Clark','1983-07-19','ryanclark@example.com','890127654321','Monaragala','2024-06-25',1,3),(42,'Sophia Hall','1996-08-14','sophiahall@example.com','901238765432','Polonnaruwa','2024-07-15',1,4),(43,'Tom Hill','1984-09-29','tomhill@example.com','012349876543','Gampaha','2024-04-05',2,5),(44,'Uma Adams','1991-10-05','umaadams@example.com','123450987654','Vavuniya','2024-02-20',1,1),(45,'Victor Brooks','1980-11-17','victorbrooks@example.com','234561098765','Kilinochchi','2024-04-10',1,2),(46,'Wendy Collins','1989-12-23','wendycollins@example.com','345672109876','Mannar','2024-04-25',2,3),(47,'Xander Evans','1977-01-12','xanderevans@example.com','456783210987','Mullaitivu','2022-12-30',2,4),(48,'Yara Foster','1998-02-22','yarafoster@example.com','567894321098','Kalutara','2023-01-15',1,5),(49,'Zach Green','1990-03-03','zachgreen@example.com','678905432109','Hambantota','2023-02-25',2,1),(50,'Anna Harris','1983-04-18','annaharris@example.com','789016543210','Badulla','2023-03-30',1,2),(51,'Brandon Johnson','1995-05-29','brandonjohnson@example.com','890127654321','Ampara','2023-04-20',1,3),(52,'Chloe King','1984-06-12','chloeking@example.com','901238765432','Puttalam','2023-05-15',2,4),(53,'Daniel Lee','1997-07-23','daniellee@example.com','012349876543','Nuwara Eliya','2023-06-30',1,5),(54,'Eva Martinez','1991-08-25','evamartinez@example.com','123450987654','Monaragala','2023-07-20',1,1),(55,'Felix Nelson','1987-09-14','felixnelson@example.com','234561098765','Polonnaruwa','2023-08-05',2,2),(56,'Gina Olson','1982-10-29','ginaolson@example.com','345672109876','Gampaha','2023-09-15',1,3),(57,'Hank Parker','1994-11-05','hankparker@example.com','456783210987','Vavuniya','2023-10-10',1,4),(58,'Irene Quinn','1985-12-17','irenequinn@example.com','567894321098','Kilinochchi','2023-11-25',2,5),(59,'Jack Roberts','1992-01-23','jackroberts@example.com','678905432109','Mannar','2023-12-30',2,1),(60,'Kara Stevens','1986-02-12','karastevens@example.com','789016543210','Mullaitivu','2024-01-10',1,2),(61,'Liam Turner','1999-03-14','liamturner@example.com','890127654321','Kalutara','2024-02-20',2,3),(62,'Megan Young','1987-03-12','meganyoung@example.com','098765432109','Galle','2023-01-15',2,4),(63,'Nathan Ross','1993-04-23','nathanross@example.com','109876543210','Kandy','2023-02-25',1,5),(64,'Olivia Spencer','1985-05-28','oliviaspencer@example.com','120987654321','Matara','2023-03-30',1,1),(65,'Patrick Wilson','1978-06-19','patrickwilson@example.com','131098765432','Negombo','2023-04-15',2,2),(66,'Quinn Taylor','1980-07-25','quinntaylor@example.com','142109876543','Kurunegala','2023-05-25',2,3),(67,'Rebecca Moore','1992-08-30','rebeccamoore@example.com','153210987654','Jaffna','2023-06-20',1,4),(68,'Samuel Green','1984-09-22','samuelgreen@example.com','164321098765','Anuradhapura','2023-07-25',2,5),(69,'Tara Nelson','1976-10-14','taranelson@example.com','175432109876','Trincomalee','2023-08-15',1,1),(70,'Ulysses Baker','1989-11-29','ulyssesbaker@example.com','186543210987','Ratnapura','2023-09-30',1,2),(71,'Vera Carter','1993-12-05','veracarter@example.com','197654321098','Batticaloa','2023-10-25',2,3),(72,'Wade Wright','1982-01-17','wadewright@example.com','208765432109','Kalutara','2023-11-30',2,4),(73,'Xena Foster','1995-02-23','xenafoster@example.com','219876543210','Hambantota','2023-12-15',1,5),(74,'Yusuf Perry','1990-03-12','yusufperry@example.com','230987654321','Badulla','2024-01-25',2,1),(75,'Zara Brooks','1985-04-14','zarabrooks@example.com','241098765432','Ampara','2024-02-28',2,2),(76,'Aiden Coleman','1991-05-23','aidencoleman@example.com','252109876543','Puttalam','2024-03-10',1,3),(77,'Bella Long','1988-06-22','bellalong@example.com','263210987654','Nuwara Eliya','2024-04-05',2,4),(78,'Charlie Torres','1996-07-27','charlietorres@example.com','274321098765','Monaragala','2024-05-25',2,5),(79,'Daisy Ramirez','1981-08-21','daisyramirez@example.com','285432109876','Polonnaruwa','2024-06-20',1,1),(80,'Ethan Campbell','1994-09-13','ethancampbell@example.com','296543210987','Gampaha','2024-07-15',2,2),(81,'Fiona Murphy','1987-10-09','fionamurphy@example.com','307654321098','Vavuniya','2024-01-05',2,3),(82,'Mason Turner','1991-05-17','masonturner@example.com','384321098765','Ampara','2024-03-10',1,5),(83,'Natalie Adams','1988-06-23','natalieadams@example.com','395432109876','Puttalam','2024-04-05',2,1),(84,'Oscar Hughes','1994-07-20','oscarlhughes@example.com','406543210987','Nuwara Eliya','2024-05-25',2,2),(85,'Paige Cook','1992-08-29','paigecook@example.com','417654321098','Monaragala','2024-06-30',1,3),(86,'Quincy Bell','1984-09-13','quincybell@example.com','428765432109','Polonnaruwa','2024-07-20',2,4),(87,'Riley Morris','1991-10-15','rileymorris@example.com','439876543210','Gampaha','2024-02-25',2,5),(88,'Sophie Price','1985-11-10','sophieprice@example.com','450987654321','Vavuniya','2024-02-15',1,1),(89,'Tyler Foster','1993-12-22','tylerfoster@example.com','461098765432','Kilinochchi','2024-04-30',2,2),(90,'Ursula Baker','1989-01-18','ursulabaker@example.com','472109876543','Mannar','2024-04-15',2,3),(91,'Victor Hughes','1995-02-14','victorhughes@example.com','483210987654','Mullaitivu','2022-12-05',1,4),(92,'Wendy Bell','1990-03-23','wendybell@example.com','494321098765','Kalutara','2024-01-25',2,5),(93,'Xander Lee','1983-04-30','xanderlee@example.com','505432109876','Hambantota','2024-02-10',2,1),(94,'Yara Davis','1992-05-17','yaradavis@example.com','516543210987','Badulla','2024-03-30',1,2),(95,'Zane Scott','1987-06-22','zanscott@example.com','527654321098','Ampara','2024-05-15',2,3),(96,'Amber Walker','1994-07-11','amberwalker@example.com','538765432109','Puttalam','2024-06-25',2,4),(97,'Brian Turner','1981-08-30','brianturner@example.com','549876543210','Nuwara Eliya','2024-03-05',1,5),(98,'Cynthia Howard','1996-09-15','cynthiahoward@example.com','550987654321','Monaragala','2024-02-20',2,1),(99,'Daniel Rogers','1989-10-30','danielrogers@example.com','561098765432','Polonnaruwa','2024-04-15',2,2),(100,'Emma Collins','1991-11-22','emmacollins@example.com','572109876543','Gampaha','2024-04-30',1,3),(101,'Finn Perry','1983-12-19','finnperry@example.com','583210987654','Vavuniya','2022-12-20',2,4),(102,'Grace Adams','1985-01-30','graceadams@example.com','594321098765','Kilinochchi','2024-01-05',1,5),(103,'Henry Murphy','1990-02-28','henrymurphy@example.com','605432109876','Mannar','2024-02-10',1,2),(104,'Ivy Brooks','1997-03-18','ivybrooks@example.com','616543210987','Mullaitivu','2024-03-15',2,3),(105,'Jackie Green','1984-04-25','jackiegreen@example.com','627654321098','Kalutara','2024-04-20',2,4),(106,'Liam Walker','1989-05-10','liamwalker@example.com','638765432109','Hambantota','2024-05-30',1,5),(107,'Mia Roberts','1992-06-21','miaroberts@example.com','649876543210','Badulla','2024-06-15',2,1),(108,'Noah Stewart','1996-07-12','noahstewart@example.com','651098765432','Ampara','2024-07-25',3,2),(109,'Olivia Bennett','1983-08-23','oliviabennett@example.com','662109876543','Puttalam','2024-04-20',1,3),(110,'Paul Morris','1985-09-18','paulmorris@example.com','673210987654','Nuwara Eliya','2024-02-10',2,4),(111,'Quinn Foster','1991-10-12','quinnfoster@example.com','684321098765','Monaragala','2024-04-25',2,5),(112,'Rachel Evans','1997-11-20','rachelevans@example.com','695432109876','Polonnaruwa','2024-04-30',1,1),(113,'Samuel Gray','1994-12-25','samuelgray@example.com','706543210987','Gampaha','2022-12-20',2,2),(114,'Tessa Clark','1987-01-05','tessaclark@example.com','717654321098','Vavuniya','2022-01-15',2,3),(115,'Ulysses Carter','1995-02-14','ulyssescarter@example.com','728765432109','Kilinochchi','2022-02-28',1,4),(116,'Vera Johnson','1984-03-30','verajohnson@example.com','739876543210','Mannar','2022-03-25',2,5),(117,'Wade Carter','1990-04-18','wadecarter@example.com','741098765432','Mullaitivu','2022-04-20',2,1),(118,'Xena Adams','1988-05-15','xenaadams@example.com','752109876543','Kalutara','2022-05-10',1,2),(119,'Yusuf Martin','1996-06-23','yusufmartin@example.com','763210987654','Hambantota','2022-06-30',2,3),(120,'Zara Griffin','1989-07-19','zaragriffin@example.com','774321098765','Badulla','2022-07-15',2,4),(121,'Aiden Nelson','1993-08-17','aidennelson@example.com','785432109876','Ampara','2022-08-25',1,5),(122,'Bella Green','1985-09-14','bellagreen@example.com','796543210987','Puttalam','2022-04-20',2,1),(123,'Caleb Baker','1990-10-22','calebbaker@example.com','807654321098','Nuwara Eliya','2022-10-30',2,2),(124,'Diana Wright','1987-11-28','dianawright@example.com','818765432109','Monaragala','2022-11-25',1,3);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customerreturn`
--

DROP TABLE IF EXISTS `customerreturn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customerreturn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` varchar(45) DEFAULT NULL,
  `invoice_id` int NOT NULL,
  `grandtotal` decimal(10,2) DEFAULT NULL,
  `employee_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customerreturn_invoice1_idx` (`invoice_id`),
  KEY `fk_customerreturn_employee1_idx` (`employee_id`),
  CONSTRAINT `fk_customerreturn_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_customerreturn_invoice1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customerreturn`
--

LOCK TABLES `customerreturn` WRITE;
/*!40000 ALTER TABLE `customerreturn` DISABLE KEYS */;
INSERT INTO `customerreturn` VALUES (8,'2024-07-30T18:30:00.000Z',59,20000.00,3),(9,'2024-08-01T01:49:31.410Z',61,19000.00,2);
/*!40000 ALTER TABLE `customerreturn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposits`
--

DROP TABLE IF EXISTS `deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `shop_id` int NOT NULL,
  `totaldeposit` decimal(12,2) DEFAULT NULL,
  `description` text,
  `employee_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_deposits_shop1_idx` (`shop_id`),
  KEY `fk_deposits_employee1_idx` (`employee_id`),
  CONSTRAINT `fk_deposits_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_deposits_shop1` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposits`
--

LOCK TABLES `deposits` WRITE;
/*!40000 ALTER TABLE `deposits` DISABLE KEYS */;
INSERT INTO `deposits` VALUES (3,'2024-08-01',2,46000.00,'sample',1),(4,'2024-08-01',3,50000.15,'sample',1),(5,'2024-08-01',16,23000.00,'sample',1),(6,'2024-08-01',15,23000.00,'sample',1),(7,'2024-08-01',14,23000.00,'sample',1),(8,'2024-08-01',13,23000.00,'sample',3),(9,'2024-08-01',12,63000.00,'sample',2),(10,'2024-08-01',1,1000.00,'Initial deposit',1),(11,'2024-08-02',4,1500.50,'Monthly deposit',2),(12,'2024-08-03',7,2000.75,'Quarterly deposit',3),(13,'2023-08-04',8,2500.00,'Yearly deposit',4),(14,'2023-08-05',10,3000.25,'Special deposit',5),(15,'2023-08-06',13,3500.50,'Emergency deposit',6),(16,'2023-08-07',16,4000.75,'Loan repayment',7),(17,'2023-08-08',17,4500.00,'Investment deposit',8),(18,'2023-08-09',19,5000.25,'Savings deposit',9),(19,'2023-08-10',20,5500.50,'Miscellaneous deposit',10),(20,'2023-08-11',2,6000.75,'Operational deposit',1),(21,'2023-08-12',5,6500.00,'Development deposit',2),(22,'2023-08-13',11,7000.25,'Insurance deposit',3),(23,'2023-08-14',14,7500.50,'Travel deposit',4),(24,'2023-08-15',3,8000.75,'Health deposit',5),(25,'2023-08-16',6,8500.00,'Education deposit',6),(26,'2023-08-17',9,9000.25,'Business deposit',7),(27,'2023-08-18',12,9500.50,'Holiday deposit',8),(28,'2023-08-19',15,10000.75,'Gift deposit',9),(29,'2024-01-05',1,1200.00,'Initial deposit',1),(30,'2024-02-15',4,1400.50,'Monthly deposit',2),(31,'2024-03-10',7,1600.75,'Quarterly deposit',3),(32,'2024-04-20',8,1800.00,'Yearly deposit',4),(33,'2024-05-25',10,2000.25,'Special deposit',5),(34,'2024-06-30',13,2200.50,'Emergency deposit',6),(35,'2024-01-12',16,2400.75,'Loan repayment',7),(36,'2024-02-22',17,2600.00,'Investment deposit',8),(37,'2024-03-18',19,2800.25,'Savings deposit',9),(38,'2024-04-15',20,3000.50,'Miscellaneous deposit',10),(39,'2024-05-05',2,3200.75,'Operational deposit',1),(40,'2024-06-10',5,3400.00,'Development deposit',2),(41,'2024-01-25',11,3600.25,'Insurance deposit',3),(42,'2024-02-12',14,3800.50,'Travel deposit',4),(43,'2024-03-30',3,4000.75,'Health deposit',5),(44,'2024-04-10',6,4200.00,'Education deposit',6),(45,'2024-05-15',9,4400.25,'Business deposit',7),(46,'2024-06-05',12,4600.50,'Holiday deposit',8),(47,'2024-01-30',15,4800.75,'Gift deposit',9),(48,'2023-12-01',1,1300.00,'Holiday deposit',1),(49,'2023-11-10',4,1450.50,'Pre-year-end deposit',2),(50,'2023-10-15',7,1600.75,'End-of-quarter deposit',3),(51,'2023-09-25',8,1750.00,'Annual deposit',4),(52,'2023-08-30',10,1900.25,'Special end-of-summer deposit',5),(53,'2023-07-05',13,2050.50,'Mid-year deposit',6),(54,'2023-06-12',16,2200.75,'Quarterly review deposit',7),(55,'2023-05-22',17,2350.00,'Investment review deposit',8),(56,'2023-04-10',19,2500.25,'Spring deposit',9),(57,'2023-03-15',20,2650.50,'Pre-tax deposit',10),(58,'2023-02-05',2,2800.75,'Operational fund',1),(59,'2023-01-10',5,2950.00,'Development fund',2),(60,'2023-06-20',11,3100.25,'Insurance premium',3),(61,'2023-05-05',14,3250.50,'Travel fund',4),(62,'2023-04-15',3,3400.75,'Healthcare fund',5),(63,'2023-03-10',6,3550.00,'Education fund',6),(64,'2023-02-15',9,3700.25,'Business expansion',7),(65,'2023-01-25',12,3850.50,'Holiday savings',8),(66,'2023-06-05',15,4000.75,'Gift fund',9),(67,'2023-12-01',1,1300.00,'Holiday deposit',1),(68,'2023-11-10',4,1450.50,'Pre-year-end deposit',2),(69,'2023-10-15',7,1600.75,'End-of-quarter deposit',3),(70,'2023-09-25',8,1750.00,'Annual deposit',4),(71,'2023-08-30',10,1900.25,'Special end-of-summer deposit',5),(72,'2023-07-05',13,2050.50,'Mid-year deposit',6),(73,'2023-06-12',16,2200.75,'Quarterly review deposit',7),(74,'2023-05-22',17,2350.00,'Investment review deposit',8),(75,'2023-04-10',19,2500.25,'Spring deposit',9),(76,'2023-03-15',20,2650.50,'Pre-tax deposit',10),(77,'2023-02-05',2,2800.75,'Operational fund',1),(78,'2023-01-10',5,2950.00,'Development fund',2),(79,'2023-06-20',11,3100.25,'Insurance premium',3),(80,'2023-05-05',14,3250.50,'Travel fund',4),(81,'2023-04-15',3,3400.75,'Healthcare fund',5),(82,'2023-03-10',6,3550.00,'Education fund',6),(83,'2023-02-15',9,3700.25,'Business expansion',7),(84,'2023-01-25',12,3850.50,'Holiday savings',8),(85,'2023-06-05',15,4000.75,'Gift fund',9),(86,'2023-12-15',1,1100.00,'End-of-year deposit',1),(87,'2023-11-01',4,1250.50,'Winter fund',2),(88,'2023-10-20',7,1400.75,'Autumn deposit',3),(89,'2023-09-05',8,1550.00,'Back-to-school deposit',4),(90,'2023-08-12',10,1700.25,'Summer savings',5),(91,'2023-07-22',13,1850.50,'Mid-summer deposit',6),(92,'2023-06-30',16,2000.75,'Summer review deposit',7),(93,'2023-05-18',17,2150.00,'Pre-summer deposit',8),(94,'2023-04-25',19,2300.25,'Spring savings',9),(95,'2023-03-15',20,2450.50,'Quarterly deposit',10),(96,'2023-02-01',2,2600.75,'Winter operational fund',1),(97,'2023-01-10',5,2750.00,'Early year deposit',2),(98,'2023-06-10',11,2900.25,'Annual review deposit',3),(99,'2023-05-01',14,3050.50,'Pre-summer fund',4),(100,'2023-04-05',3,3200.75,'Healthcare savings',5),(101,'2023-03-10',6,3350.00,'Educational fund',6),(102,'2023-02-20',9,3500.25,'Business fund',7),(103,'2023-01-25',12,3650.50,'Year-start deposit',8),(104,'2023-06-05',15,3800.75,'Gift savings',9),(105,'2023-12-01',13,1300.00,'Holiday deposit',1),(106,'2023-11-10',13,1450.50,'Pre-year-end deposit',2),(107,'2023-10-15',13,1600.75,'End-of-quarter deposit',3),(108,'2023-09-25',13,1750.00,'Annual deposit',4),(109,'2023-08-30',13,1900.25,'Special end-of-summer deposit',5),(110,'2023-07-05',13,2050.50,'Mid-year deposit',6),(111,'2023-06-12',13,2200.75,'Quarterly review deposit',7),(112,'2023-05-22',13,2350.00,'Investment review deposit',8),(113,'2023-04-10',13,2500.25,'Spring deposit',9),(114,'2023-03-15',13,2650.50,'Pre-tax deposit',10),(115,'2023-02-05',13,2800.75,'Operational fund',1),(116,'2023-01-10',13,2950.00,'Development fund',2),(117,'2023-06-20',13,3100.25,'Insurance premium',3),(118,'2023-05-05',13,3250.50,'Travel fund',4),(119,'2023-04-15',13,3400.75,'Healthcare fund',5),(120,'2023-03-10',13,3550.00,'Education fund',6),(121,'2023-02-15',13,3700.25,'Business expansion',7),(122,'2023-01-25',13,3850.50,'Holiday savings',8),(123,'2023-06-05',13,4000.75,'Gift fund',9),(124,'2024-01-05',13,1200.00,'Initial deposit',1),(125,'2024-01-15',13,1300.50,'Mid-January deposit',2),(126,'2024-02-05',13,1400.75,'Early February deposit',3),(127,'2024-02-15',13,1500.00,'Mid-February deposit',4),(128,'2024-03-05',13,1600.25,'Early March deposit',5),(129,'2024-03-15',13,1700.50,'Mid-March deposit',6),(130,'2024-04-05',13,1800.75,'Early April deposit',7),(131,'2024-04-15',13,1900.00,'Mid-April deposit',8),(132,'2024-05-05',13,2000.25,'Early May deposit',9),(133,'2024-05-15',13,2100.50,'Mid-May deposit',10),(134,'2024-06-05',13,2200.75,'Early June deposit',1),(135,'2024-06-15',13,2300.00,'Mid-June deposit',2),(136,'2024-01-20',13,1250.00,'Late January deposit',3),(137,'2024-02-20',13,1350.50,'Late February deposit',4),(138,'2024-03-20',13,1450.75,'Late March deposit',5),(139,'2024-04-20',13,1550.00,'Late April deposit',6),(140,'2024-05-20',13,1650.25,'Late May deposit',7),(141,'2024-06-20',13,1750.50,'Late June deposit',8),(142,'2024-06-30',13,1850.75,'End-of-June deposit',9),(143,'2024-01-07',13,1250.00,'Deposit for the first week of January',1),(144,'2024-01-22',13,1350.50,'Mid-month deposit',2),(145,'2024-02-01',13,1450.75,'Beginning of February deposit',3),(146,'2024-02-14',13,1550.00,'Valentine’s deposit',4),(147,'2024-03-03',13,1650.25,'Start of March deposit',5),(148,'2024-03-18',13,1750.50,'Mid-March deposit',6),(149,'2024-04-02',13,1850.75,'First April deposit',7),(150,'2024-04-17',13,1950.00,'Mid-April deposit',8),(151,'2024-05-03',13,2050.25,'Start of May deposit',9),(152,'2024-05-16',13,2150.50,'Mid-May deposit',10),(153,'2024-06-01',13,2250.75,'Beginning of June deposit',1),(154,'2024-06-12',13,2350.00,'Early June deposit',2),(155,'2024-06-25',13,2450.25,'End-of-month deposit',3),(156,'2024-01-18',13,1300.00,'Late January deposit',4),(157,'2024-02-08',13,1400.50,'Second week of February deposit',5),(158,'2024-03-08',13,1500.75,'Second week of March deposit',6),(159,'2024-04-08',13,1600.00,'Second week of April deposit',7),(160,'2024-05-08',13,1700.25,'Second week of May deposit',8),(161,'2024-06-08',13,1800.50,'Second week of June deposit',9);
/*!40000 ALTER TABLE `deposits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `designation`
--

DROP TABLE IF EXISTS `designation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `designation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `designation`
--

LOCK TABLES `designation` WRITE;
/*!40000 ALTER TABLE `designation` DISABLE KEYS */;
INSERT INTO `designation` VALUES (1,'Manager'),(2,'Assistant Manager'),(3,'Clerk'),(4,'Supervisor'),(5,'Director'),(6,'Coordinator'),(7,'Analyst'),(8,'Executive'),(9,'Officer'),(10,'Technician'),(11,'Consultant'),(12,'Specialist'),(13,'Engineer');
/*!40000 ALTER TABLE `designation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disitem`
--

DROP TABLE IF EXISTS `disitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `disrequests_id` int NOT NULL,
  `Item_id` int NOT NULL,
  `qty` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_disrequests_has_Item_Item1_idx` (`Item_id`),
  KEY `fk_disrequests_has_Item_disrequests1_idx` (`disrequests_id`),
  CONSTRAINT `fk_disrequests_has_Item_disrequests1` FOREIGN KEY (`disrequests_id`) REFERENCES `disrequests` (`id`),
  CONSTRAINT `fk_disrequests_has_Item_Item1` FOREIGN KEY (`Item_id`) REFERENCES `Item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disitem`
--

LOCK TABLES `disitem` WRITE;
/*!40000 ALTER TABLE `disitem` DISABLE KEYS */;
INSERT INTO `disitem` VALUES (29,22,2,2),(30,23,2,3),(33,26,2,2),(38,31,2,3),(39,32,2,5),(40,33,3,2),(41,34,2,2),(48,38,2,2),(49,37,1,2),(50,35,1,3),(51,36,3,1),(52,30,2,4),(53,29,3,3),(54,28,3,1),(55,27,2,2),(56,25,70,2),(57,25,87,2),(58,24,85,2),(59,21,89,2),(60,21,92,2),(63,20,54,1),(64,39,2,1);
/*!40000 ALTER TABLE `disitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disorder`
--

DROP TABLE IF EXISTS `disorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disorder` (
  `id` int NOT NULL AUTO_INCREMENT,
  `disonumber` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` text,
  `disrequests_id` int NOT NULL,
  `postatus_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `vehicle_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_disorder_disrequests1_idx` (`disrequests_id`),
  KEY `fk_disorder_postatus1_idx` (`postatus_id`),
  KEY `fk_disorder_employee1_idx` (`employee_id`),
  KEY `fk_disorder_vehicle1_idx` (`vehicle_id`),
  CONSTRAINT `fk_disorder_disrequests1` FOREIGN KEY (`disrequests_id`) REFERENCES `disrequests` (`id`),
  CONSTRAINT `fk_disorder_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_disorder_postatus1` FOREIGN KEY (`postatus_id`) REFERENCES `postatus` (`id`),
  CONSTRAINT `fk_disorder_vehicle1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disorder`
--

LOCK TABLES `disorder` WRITE;
/*!40000 ALTER TABLE `disorder` DISABLE KEYS */;
INSERT INTO `disorder` VALUES (6,'DOR202408010002','2024-08-01','sample',19,11,1,15),(7,'DOR202408010003','2024-08-01','sample',20,11,2,20),(8,'DOR202408010004','2024-08-01','sample',21,1,2,76),(10,'DOR202408010005','2024-08-01','sample',22,2,1,86),(11,'DOR202408010006','2024-08-01','sample',23,2,1,91);
/*!40000 ALTER TABLE `disorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disorderitem`
--

DROP TABLE IF EXISTS `disorderitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disorderitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qty` varchar(45) DEFAULT NULL,
  `disorder_id` int NOT NULL,
  `Item_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_disorderitem_disorder1_idx` (`disorder_id`),
  KEY `fk_disorderitem_Item1_idx` (`Item_id`),
  CONSTRAINT `fk_disorderitem_disorder1` FOREIGN KEY (`disorder_id`) REFERENCES `disorder` (`id`),
  CONSTRAINT `fk_disorderitem_Item1` FOREIGN KEY (`Item_id`) REFERENCES `Item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disorderitem`
--

LOCK TABLES `disorderitem` WRITE;
/*!40000 ALTER TABLE `disorderitem` DISABLE KEYS */;
INSERT INTO `disorderitem` VALUES (3,'2',6,2),(4,'1',6,26),(5,'1',7,54),(6,'1',8,89),(7,'1',8,92),(10,'1',10,2),(11,'1',11,2);
/*!40000 ALTER TABLE `disorderitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disreceive`
--

DROP TABLE IF EXISTS `disreceive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disreceive` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `description` text,
  `disorder_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `disrecnumber` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_disreceive_disorder1_idx` (`disorder_id`),
  KEY `fk_disreceive_employee1_idx` (`employee_id`),
  CONSTRAINT `fk_disreceive_disorder1` FOREIGN KEY (`disorder_id`) REFERENCES `disorder` (`id`),
  CONSTRAINT `fk_disreceive_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disreceive`
--

LOCK TABLES `disreceive` WRITE;
/*!40000 ALTER TABLE `disreceive` DISABLE KEYS */;
INSERT INTO `disreceive` VALUES (3,'2024-08-01','sample',6,1,'DRO202408010001'),(4,'2024-08-01','sample',7,1,'DRO202408010002');
/*!40000 ALTER TABLE `disreceive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disrequests`
--

DROP TABLE IF EXISTS `disrequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disrequests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `disnumber` varchar(45) DEFAULT NULL,
  `reqdate` date DEFAULT NULL,
  `description` text,
  `disstatus_id` int NOT NULL,
  `shop_id` int NOT NULL,
  `employee_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_disrequests_disstatus1_idx` (`disstatus_id`),
  KEY `fk_disrequests_shop1_idx` (`shop_id`),
  KEY `fk_disrequests_employee1_idx` (`employee_id`),
  CONSTRAINT `fk_disrequests_disstatus1` FOREIGN KEY (`disstatus_id`) REFERENCES `disstatus` (`id`),
  CONSTRAINT `fk_disrequests_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_disrequests_shop1` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disrequests`
--

LOCK TABLES `disrequests` WRITE;
/*!40000 ALTER TABLE `disrequests` DISABLE KEYS */;
INSERT INTO `disrequests` VALUES (19,'DRQ202408010002','2024-08-01','sample',4,1,1),(20,'DRQ202408010003','2024-08-01','sample',4,1,3),(21,'DRQ202408010004','2024-08-01','sample',2,2,2),(22,'DRQ202408010005','2024-08-01','sample',2,2,1),(23,'DRQ202408010006','2024-08-01','sample',2,2,2),(24,'DRQ202408010007','2024-08-01','sample',2,2,3),(25,'DRQ202408010008','2024-08-01','sample',4,2,1),(26,'DRQ202408010009','2024-08-01','sample',4,1,1),(27,'DRQ202408010010','2024-08-01','sample',4,2,1),(28,'DRQ202408010011','2024-08-01','sample',4,2,4),(29,'DRQ202408010012','2024-08-01','sample',1,2,2),(30,'DRQ202408010013','2024-08-01','sample',1,3,3),(31,'DRQ202408010014','2024-08-01','sample',1,7,3),(32,'DRQ202408010015','2024-08-01','sample',1,3,2),(33,'DRQ202408010016','2024-08-01','sample',3,3,1),(34,'DRQ202408010017','2024-08-01','sample',3,3,3),(35,'DRQ202408010018','2024-08-01','sample',1,3,3),(36,'DRQ202408010019','2024-08-01','sample',1,3,2),(37,'DRQ202408010020','2024-08-01','sample',1,4,3),(38,'DRQ202408010021','2024-08-01','sample',1,4,4),(39,'DRQ202408020001','2024-08-02','sample',1,1,1);
/*!40000 ALTER TABLE `disrequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disstatus`
--

DROP TABLE IF EXISTS `disstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disstatus`
--

LOCK TABLES `disstatus` WRITE;
/*!40000 ALTER TABLE `disstatus` DISABLE KEYS */;
INSERT INTO `disstatus` VALUES (1,'Pending'),(2,'Approved'),(3,'Rejected'),(4,'Completed');
/*!40000 ALTER TABLE `disstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` char(4) DEFAULT NULL,
  `fullname` varchar(150) DEFAULT NULL,
  `callingname` varchar(45) DEFAULT NULL,
  `photo` longblob,
  `gender_id` int NOT NULL,
  `dobirth` date DEFAULT NULL,
  `nic` char(12) DEFAULT NULL,
  `address` text,
  `mobile` char(10) DEFAULT NULL,
  `land` char(10) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `emptype_id` int NOT NULL,
  `designation_id` int NOT NULL,
  `doassignment` date DEFAULT NULL,
  `description` text,
  `empstatus_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_employee_gender_idx` (`gender_id`),
  KEY `fk_employee_designation1_idx` (`designation_id`),
  KEY `fk_employee_empstatus1_idx` (`empstatus_id`),
  KEY `fk_employee_emptype1_idx` (`emptype_id`),
  CONSTRAINT `fk_employee_designation1` FOREIGN KEY (`designation_id`) REFERENCES `designation` (`id`),
  CONSTRAINT `fk_employee_empstatus1` FOREIGN KEY (`empstatus_id`) REFERENCES `empstatus` (`id`),
  CONSTRAINT `fk_employee_emptype1` FOREIGN KEY (`emptype_id`) REFERENCES `emptype` (`id`),
  CONSTRAINT `fk_employee_gender` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'0001','John Doe','John',NULL,1,'1980-01-01','123456789V','123 Main St','0712345678','0112345678','john.doe@example.com',1,1,'2024-01-01','New employee',1),(2,'0002','Jane Smith','Jane',NULL,2,'1990-02-02','234567890V','456 Elm St','0712345679','0112345679','jane.smith@example.com',2,2,'2024-02-01','HR Manager',2),(3,'0003','Emily Johnson','Emily',NULL,2,'1985-03-03','345678901V','789 Oak St','0712345680','0112345680','emily.johnson@example.com',3,3,'2024-03-01','Sales Manager',1),(4,'0004','Michael Brown','Mike',NULL,1,'1975-04-04','456789012V','101 Maple St','0712345681','0112345681','michael.brown@example.com',4,4,'2024-04-01','IT Specialist',3),(5,'0005','David Wilson','David',NULL,1,'1988-05-05','567890123V','202 Pine St','0712345682','0112345682','david.wilson@example.com',5,5,'2024-05-01','Finance Officer',1),(6,'0006','Sarah Davis','Sarah',NULL,2,'1992-06-06','678901234V','303 Birch St','0712345683','0112345683','sarah.davis@example.com',6,6,'2024-06-01','Marketing Manager',2),(7,'0007','Chris Martin','Chris',NULL,1,'1993-07-07','789012345V','404 Cedar St','0712345684','0112345684','chris.martin@example.com',1,7,'2024-07-01','Operations Manager',2),(8,'0008','Laura Taylor','Laura',NULL,2,'1987-08-08','890123456V','505 Spruce St','0712345685','0112345685','laura.taylor@example.com',2,8,'2024-08-01','Customer Service Rep',3),(9,'0009','Brian Anderson','Brian',NULL,1,'1980-09-09','901234567V','606 Fir St','0712345686','0112345686','brian.anderson@example.com',3,9,'2024-09-01','Product Manager',1),(10,'0010','Linda Thompson','Linda',NULL,2,'1995-10-10','012345678V','707 Willow St','0712345687','0112345687','linda.thompson@example.com',4,10,'2024-10-01','Software Engineer',3),(11,'0011','Paul Walker','Paul',NULL,1,'1982-11-11','112345678V','808 Chestnut St','0712345688','0112345688','paul.walker@example.com',1,11,'2024-11-01','Logistics Manager',1),(12,'0012','Jessica Lee','Jess',NULL,2,'1989-12-12','223456789V','909 Walnut St','0712345689','0112345689','jessica.lee@example.com',2,12,'2024-12-01','Quality Analyst',2),(13,'0013','Kevin Harris','Kevin',NULL,1,'1978-01-13','334567890V','1010 Hickory St','0712345690','0112345690','kevin.harris@example.com',3,13,'2024-01-15','Research Scientist',3),(14,'0014','Emma Clark','Emma',NULL,2,'1984-02-14','445678901V','1111 Poplar St','0712345691','0112345691','emma.clark@example.com',4,1,'2024-02-15','Project Manager',1),(15,'0015','George Adams','George',NULL,1,'1991-03-15','556789012V','1212 Alder St','0712345692','0112345692','george.adams@example.com',5,2,'2024-03-15','HR Specialist',2),(16,'0016','Olivia Baker','Olivia',NULL,2,'1986-04-16','667890123V','1313 Sycamore St','0712345693','0112345693','olivia.baker@example.com',6,3,'2024-04-15','Business Analyst',3),(17,'0017','James Scott','James',NULL,1,'1979-05-17','778901234V','1414 Magnolia St','0712345694','0112345694','james.scott@example.com',1,4,'2024-05-15','Technical Lead',1),(18,'0018','Sophia King','Sophia',NULL,2,'1990-06-18','889012345V','1515 Aspen St','0712345695','0112345695','sophia.king@example.com',2,5,'2024-06-15','Financial Analyst',2),(19,'0019','Daniel Moore','Daniel',NULL,1,'1983-07-19','990123456V','1616 Dogwood St','0712345696','0112345696','daniel.moore@example.com',3,6,'2024-07-15','Network Administrator',3),(20,'2202','Dileesha Rukmal','Rukmal',NULL,1,'2001-01-02','200008402775','Kagalle ','0769666666',NULL,NULL,1,1,'2022-01-01','BIT UG',1),(21,'0020','Mia Davis','Mia',NULL,2,'1992-08-20','001234567V','1717 Olive St','0712345697','0112345697','mia.davis@example.com',4,7,'2024-08-15','Marketing Specialist',1),(22,'2301','Lakshan Ruwinda','Lakshan',NULL,1,'2001-01-04','200123701980','Kirindiwala','0729666666',NULL,NULL,2,1,'2023-01-01','BIT UG',2),(23,'2302','Arshad Ahamad','Arshad',NULL,1,'2001-01-05',NULL,'Galle ','0759666666',NULL,NULL,3,1,'2023-01-01','BIT/BSC UG',3),(24,'2303','Imasha Gaupadi','Imasha ',NULL,2,'2001-01-06',NULL,'Galle','0789666666',NULL,NULL,4,1,'2023-01-01','BIT UG/TTC',1),(38,'2209','Dileesha Rukmal','Dileesha',NULL,1,'2000-03-24','200124500277','Kagalle','0775555555','0362288888',NULL,5,1,'2023-05-17','Good in Coding',2),(39,'2345','Nanda Malini','Nanda',NULL,2,'2023-05-17','195488888888','Colombo','0766666666','0112223344',NULL,6,5,'2023-05-16','Best Singer ',3),(41,'9923','Gunadasa Kapuge','Kapuge',NULL,2,'2023-05-05','078678889098','Colombo','0789999999','0333344444',NULL,1,4,'2023-05-16','Singer',1),(42,'0489','Dimuthu','Surnaga',NULL,1,NULL,'198020300703','Waliweriya','0772307929','0332255557',NULL,2,1,NULL,'Not',2),(43,'0406','Dimuthu','Suranga',NULL,1,NULL,'198020300704','Waliwriya','0772307929','0332255551',NULL,3,1,'2023-05-23','dsd',1),(46,'0002','Jane Smith','Jane',NULL,2,'1990-02-02','234567890V','456 Elm St','0712345679','0112345679','jane.smith@example.com',2,2,'2024-02-01','HR Manager',2),(47,'0003','Emily Johnson','Emily',NULL,2,'1985-03-03','345678901V','789 Oak St','0712345680','0112345680','emily.johnson@example.com',3,3,'2024-03-01','Sales Manager',1),(48,'0004','Michael Brown','Mike',NULL,1,'1975-04-04','456789012V','101 Maple St','0712345681','0112345681','michael.brown@example.com',4,4,'2024-04-01','IT Specialist',3),(49,'0005','David Wilson','David',NULL,1,'1988-05-05','567890123V','202 Pine St','0712345682','0112345682','david.wilson@example.com',5,5,'2024-05-01','Finance Officer',1),(50,'0006','Sarah Davis','Sarah',NULL,2,'1992-06-06','678901234V','303 Birch St','0712345683','0112345683','sarah.davis@example.com',6,6,'2024-06-01','Marketing Manager',2),(51,'0007','Chris Martin','Chris',NULL,1,'1993-07-07','789012345V','404 Cedar St','0712345684','0112345684','chris.martin@example.com',1,7,'2024-07-01','Operations Manager',2),(52,'0008','Laura Taylor','Laura',NULL,2,'1987-08-08','890123456V','505 Spruce St','0712345685','0112345685','laura.taylor@example.com',2,8,'2024-08-01','Customer Service Rep',3),(53,'0009','Brian Anderson','Brian',NULL,1,'1980-09-09','901234567V','606 Fir St','0712345686','0112345686','brian.anderson@example.com',3,9,'2024-09-01','Product Manager',1),(54,'0010','Linda Thompson','Linda',NULL,2,'1995-10-10','012345678V','707 Willow St','0712345687','0112345687','linda.thompson@example.com',4,10,'2024-10-01','Software Engineer',3),(55,'0011','Paul Walker','Paul',NULL,1,'1982-11-11','112345678V','808 Chestnut St','0712345688','0112345688','paul.walker@example.com',1,11,'2024-11-01','Logistics Manager',1),(56,'0012','Jessica Lee','Jess',NULL,2,'1989-12-12','223456789V','909 Walnut St','0712345689','0112345689','jessica.lee@example.com',2,12,'2024-12-01','Quality Analyst',2),(57,'0013','Kevin Harris','Kevin',NULL,1,'1978-01-13','334567890V','1010 Hickory St','0712345690','0112345690','kevin.harris@example.com',3,13,'2024-01-15','Research Scientist',3),(58,'0014','Emma Clark','Emma',NULL,2,'1984-02-14','445678901V','1111 Poplar St','0712345691','0112345691','emma.clark@example.com',4,1,'2024-02-15','Project Manager',1),(59,'0015','George Adams','George',NULL,1,'1991-03-15','556789012V','1212 Alder St','0712345692','0112345692','george.adams@example.com',5,2,'2024-03-15','HR Specialist',2),(60,'0016','Olivia Baker','Olivia',NULL,2,'1986-04-16','667890123V','1313 Sycamore St','0712345693','0112345693','olivia.baker@example.com',6,3,'2024-04-15','Business Analyst',3),(61,'0017','James Scott','James',NULL,1,'1979-05-17','778901234V','1414 Magnolia St','0712345694','0112345694','james.scott@example.com',1,4,'2024-05-15','Technical Lead',1),(62,'0018','Sophia King','Sophia',NULL,2,'1990-06-18','889012345V','1515 Aspen St','0712345695','0112345695','sophia.king@example.com',2,5,'2024-06-15','Financial Analyst',2),(63,'0019','Daniel Moore','Daniel',NULL,1,'1983-07-19','990123456V','1616 Dogwood St','0712345696','0112345696','daniel.moore@example.com',3,6,'2024-07-15','Network Administrator',3),(64,'0020','Mia Davis','Mia',NULL,2,'1992-08-20','001234567V','1717 Olive St','0712345697','0112345697','mia.davis@example.com',4,7,'2024-08-15','Marketing Specialist',1),(65,'0021','Mark Allen','Mark',NULL,1,'1981-09-21','112234567V','1818 Beech St','0712345698','0112345698','mark.allen@example.com',1,8,'2024-09-01','Security Officer',1),(66,'0022','Nancy Wright','Nancy',NULL,2,'1985-10-22','223345678V','1919 Elmwood St','0712345699','0112345699','nancy.wright@example.com',2,9,'2024-10-01','IT Support',2),(67,'0023','Robert White','Rob',NULL,1,'1976-11-23','334456789V','2020 Hawthorn St','0712345700','0112345700','robert.white@example.com',3,10,'2024-11-01','System Administrator',3),(68,'0024','Michelle Green','Michelle',NULL,2,'1988-12-24','445567890V','2121 Laurel St','0712345701','0112345701','michelle.green@example.com',4,11,'2024-12-01','Database Manager',1),(69,'0025','Thomas Baker','Tom',NULL,1,'1984-01-25','556678901V','2222 Sprucewood St','0712345702','0112345702','thomas.baker@example.com',5,12,'2024-01-15','Data Analyst',2),(70,'0026','Elizabeth Mitchell','Liz',NULL,2,'1991-02-26','667789012V','2323 Pinewood St','0712345703','0112345703','elizabeth.mitchell@example.com',6,13,'2024-02-15','Sales Executive',3),(71,'0027','Steven Gonzalez','Steve',NULL,1,'1987-03-27','778890123V','2424 Maplewood St','0712345704','0112345704','steven.gonzalez@example.com',1,1,'2024-03-15','Operations Coordinator',1),(72,'0028','Rebecca Perez','Becca',NULL,2,'1992-04-28','889901234V','2525 Birchwood St','0712345705','0112345705','rebecca.perez@example.com',2,2,'2024-04-15','Marketing Assistant',2),(73,'0029','Andrew Martinez','Andrew',NULL,1,'1983-05-29','990012345V','2626 Oakwood St','0712345706','0112345706','andrew.martinez@example.com',3,3,'2024-05-15','Product Specialist',3),(74,'0030','Anna Wilson','Anna',NULL,2,'1986-06-30','001123456V','2727 Redwood St','0712345707','0112345707','anna.wilson@example.com',4,4,'2024-06-15','Finance Manager',1);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empstatus`
--

DROP TABLE IF EXISTS `empstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empstatus`
--

LOCK TABLES `empstatus` WRITE;
/*!40000 ALTER TABLE `empstatus` DISABLE KEYS */;
INSERT INTO `empstatus` VALUES (1,'Employed'),(2,'Unemployed'),(3,'Intern');
/*!40000 ALTER TABLE `empstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emptype`
--

DROP TABLE IF EXISTS `emptype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emptype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emptype`
--

LOCK TABLES `emptype` WRITE;
/*!40000 ALTER TABLE `emptype` DISABLE KEYS */;
INSERT INTO `emptype` VALUES (1,'Full-time '),(2,'Part-time'),(3,'Temporary'),(4,'Seasonal'),(5,'Leased'),(6,'At-will');
/*!40000 ALTER TABLE `emptype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gender`
--

DROP TABLE IF EXISTS `gender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gender` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gender`
--

LOCK TABLES `gender` WRITE;
/*!40000 ALTER TABLE `gender` DISABLE KEYS */;
INSERT INTO `gender` VALUES (1,'Male'),(2,'Female '),(3,'Other');
/*!40000 ALTER TABLE `gender` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade`
--

DROP TABLE IF EXISTS `grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grade`
--

LOCK TABLES `grade` WRITE;
/*!40000 ALTER TABLE `grade` DISABLE KEYS */;
INSERT INTO `grade` VALUES (1,'A-class'),(2,'B-class '),(3,'C-class'),(4,'E-class(Expressways)'),(5,'D-class');
/*!40000 ALTER TABLE `grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grn`
--

DROP TABLE IF EXISTS `grn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` varchar(45) DEFAULT NULL,
  `description` text,
  `grandtotal` decimal(12,2) DEFAULT NULL,
  `employee_id` int NOT NULL,
  `grnstatus_id` int NOT NULL,
  `purorder_id` int NOT NULL,
  `grnnumber` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_grn_employee1_idx` (`employee_id`),
  KEY `fk_grn_grnstatus1_idx` (`grnstatus_id`),
  KEY `fk_grn_purorder1_idx` (`purorder_id`),
  CONSTRAINT `fk_grn_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_grn_grnstatus1` FOREIGN KEY (`grnstatus_id`) REFERENCES `grnstatus` (`id`),
  CONSTRAINT `fk_grn_purorder1` FOREIGN KEY (`purorder_id`) REFERENCES `purorder` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grn`
--

LOCK TABLES `grn` WRITE;
/*!40000 ALTER TABLE `grn` DISABLE KEYS */;
INSERT INTO `grn` VALUES (28,'2024-07-31','sample',1800.00,2,1,32,'GRN202407310003'),(29,'2024-07-31','sample',560.00,2,7,33,'GRN202407310004'),(30,'2024-07-31T04:34:52.654Z','sample',38000.00,2,1,34,'GRN202407310005'),(32,'2024-07-31','sample',19000.00,2,1,35,'GRN202407310006'),(33,'2024-08-01T04:05:01.581Z','sample',13200.00,4,8,36,'GRN202408010001');
/*!40000 ALTER TABLE `grn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grnitem`
--

DROP TABLE IF EXISTS `grnitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grnitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unitcost` decimal(8,2) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `linecost` decimal(8,2) DEFAULT NULL,
  `grn_id` int NOT NULL,
  `Item_id` int NOT NULL,
  `store_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_grnitem_grn1_idx` (`grn_id`),
  KEY `fk_grnitem_Item1_idx` (`Item_id`),
  KEY `fk_grnitem_store1_idx` (`store_id`),
  CONSTRAINT `fk_grnitem_grn1` FOREIGN KEY (`grn_id`) REFERENCES `grn` (`id`),
  CONSTRAINT `fk_grnitem_Item1` FOREIGN KEY (`Item_id`) REFERENCES `Item` (`id`),
  CONSTRAINT `fk_grnitem_store1` FOREIGN KEY (`store_id`) REFERENCES `store` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grnitem`
--

LOCK TABLES `grnitem` WRITE;
/*!40000 ALTER TABLE `grnitem` DISABLE KEYS */;
INSERT INTO `grnitem` VALUES (29,19000.00,2,38000.00,30,1,1),(32,280.00,2,560.00,29,69,1),(33,900.00,2,1800.00,28,75,1),(36,200.00,95,19000.00,32,3,1),(37,330.00,40,13200.00,33,50,4);
/*!40000 ALTER TABLE `grnitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grnstatus`
--

DROP TABLE IF EXISTS `grnstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grnstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grnstatus`
--

LOCK TABLES `grnstatus` WRITE;
/*!40000 ALTER TABLE `grnstatus` DISABLE KEYS */;
INSERT INTO `grnstatus` VALUES (1,'Received'),(2,'Partially Received'),(6,'Cancelled'),(7,'Closed'),(8,'Return');
/*!40000 ALTER TABLE `grnstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `grandtotal` decimal(10,2) DEFAULT NULL,
  `customer_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `shop_id` int NOT NULL,
  `invnumber` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_invoice_customer1_idx` (`customer_id`),
  KEY `fk_invoice_employee1_idx` (`employee_id`),
  KEY `fk_invoice_shop1_idx` (`shop_id`),
  CONSTRAINT `fk_invoice_customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `fk_invoice_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_invoice_shop1` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (45,'2024-07-31',2000.00,2,1,1,'INV202407310005'),(46,'2024-07-31',2000.00,1,1,1,'INV202407310006'),(47,'2024-07-31',0.15,1,1,2,'INV202407310007'),(48,'2024-07-31',3000.00,6,2,3,'INV202407310008'),(49,'2024-07-31',1500.00,5,1,4,'INV202407310009'),(50,'2024-07-31',660.00,1,4,10,'INV202407310010'),(51,'2024-07-31',0.20,1,2,3,'INV202407310011'),(52,'2024-07-31',4000.00,2,2,17,'INV202407310012'),(53,'2024-07-31',20000.00,19,1,1,'INV202407310013'),(54,'2024-07-31',2000.00,16,3,3,'INV202407310014'),(55,'2024-07-31',20000.00,5,1,1,'INV202407310015'),(56,'2024-07-31',2000.00,1,2,1,'INV202407310016'),(57,'2024-07-31',2000.00,4,1,2,'INV202407310017'),(58,'2024-07-31',2000.00,23,1,2,'INV202407310018'),(59,'2024-07-31',40000.00,4,3,13,'INV202407310019'),(60,'2024-07-31',20000.00,21,1,12,'INV202407310020'),(61,'2024-07-31',19000.00,8,1,17,'INV202407310021');
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Item`
--

DROP TABLE IF EXISTS `Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `itemnumber` varchar(45) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `sprice` decimal(7,2) DEFAULT NULL,
  `pprice` decimal(7,2) DEFAULT NULL,
  `poto` longblob,
  `quantity` decimal(8,2) DEFAULT NULL,
  `rop` int DEFAULT NULL,
  `dointroduced` date DEFAULT NULL,
  `subcategory_id` int NOT NULL,
  `itembrand_id` int NOT NULL,
  `itemstatus_id` int NOT NULL,
  `unittype_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Item_subcategory1_idx` (`subcategory_id`),
  KEY `fk_Item_itembrand1_idx` (`itembrand_id`),
  KEY `fk_Item_itemstatus1_idx` (`itemstatus_id`),
  KEY `fk_Item_unittype1_idx` (`unittype_id`),
  KEY `fk_Item_supplier1_idx` (`supplier_id`),
  CONSTRAINT `fk_Item_itembrand1` FOREIGN KEY (`itembrand_id`) REFERENCES `itembrand` (`id`),
  CONSTRAINT `fk_Item_itemstatus1` FOREIGN KEY (`itemstatus_id`) REFERENCES `itemstatus` (`id`),
  CONSTRAINT `fk_Item_subcategory1` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategory` (`id`),
  CONSTRAINT `fk_Item_supplier1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`),
  CONSTRAINT `fk_Item_unittype1` FOREIGN KEY (`unittype_id`) REFERENCES `unittype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Item`
--

LOCK TABLES `Item` WRITE;
/*!40000 ALTER TABLE `Item` DISABLE KEYS */;
INSERT INTO `Item` VALUES (1,'ITM0000001','Smartphone Model X',1000.00,19000.00,NULL,30.00,20,'2023-01-15',1,1,1,1,1),(2,'ITM0000002','Laptop Model Y',1000.00,10.25,NULL,4.00,5,'2023-02-20',1,2,1,1,2),(3,'ITM0000003','Sofa Set',2000.00,200.00,NULL,6.00,10,'2023-03-10',2,3,1,1,3),(4,'ITM0000004','Men\'s Shirt',100.00,29.99,NULL,1000.00,20,'2023-04-05',3,4,1,1,4),(5,'ITM0000005','Snack Pack',200.00,4.99,NULL,200.00,50,'2023-05-15',4,5,1,1,5),(26,'ITM0000006','Office Desk',20000.00,299.99,NULL,15.00,20,'2023-06-01',15,6,1,10,6),(36,'ITM0000007','Running Shoes',2000.00,79.99,NULL,50.00,10,'2023-07-10',19,7,1,19,7),(38,'ITM0000008','Baby Diapers',1000.00,39.99,NULL,150.00,30,'2023-09-20',17,9,1,17,9),(40,'ITM0000009','Sri Lankan Tea',500.00,550.00,NULL,100.00,10,'2024-01-15',5,3,7,12,8),(41,'ITM0000010','Sri Lankan Tea',500.00,550.00,NULL,97.00,10,'2024-01-15',5,3,7,12,8),(42,'ITM0000011','Coconut Oil',300.00,320.00,NULL,200.00,20,'2024-01-16',10,7,9,15,12),(43,'ITM0000012','Spices Pack',150.00,180.00,NULL,150.00,15,'2024-01-17',15,10,8,17,14),(44,'ITM0000013','Rice 5kg',800.00,850.00,NULL,50.00,100,'2024-01-18',20,12,6,18,16),(45,'ITM0000014','Dried Fish',200.00,220.00,NULL,80.00,8,'2024-01-19',8,5,11,19,20),(46,'ITM0000015','Jaggery',120.00,130.00,NULL,60.00,6,'2024-01-20',25,8,12,14,21),(47,'ITM0000016','Sambol Mix',250.00,270.00,NULL,120.00,12,'2024-01-21',30,11,7,13,22),(48,'ITM0000017','Cinnamon Sticks',350.00,370.00,NULL,90.00,9,'2024-01-22',35,6,10,16,23),(49,'ITM0000018','Pepper Powder',200.00,220.00,NULL,110.00,11,'2024-01-23',40,4,9,17,24),(50,'ITM0000019','Turmeric Powder',180.00,330.00,NULL,160.00,13,'2024-01-24',45,9,8,12,25),(51,'ITM0000020','Ginger Paste',250.00,270.00,NULL,70.00,7,'2024-01-25',50,14,13,19,5),(52,'ITM0000021','Cardamom',400.00,420.00,NULL,60.00,6,'2024-01-26',55,1,12,18,6),(53,'ITM0000022','Curry Powder',220.00,270.00,NULL,137.00,14,'2024-01-27',60,13,11,20,7),(54,'ITM0000023','Cloves',300.00,320.00,NULL,80.00,8,'2024-01-28',1,2,14,15,8),(55,'ITM0000024','Black Salt',100.00,120.00,NULL,90.00,9,'2024-01-29',2,3,9,12,9),(56,'ITM0000025','Chili Powder',170.00,190.00,NULL,110.00,11,'2024-01-30',3,4,10,14,10),(57,'ITM0000026','Tamarind',140.00,160.00,NULL,70.00,7,'2024-01-31',4,5,11,17,11),(58,'ITM0000027','Mustard Seeds',130.00,150.00,NULL,85.00,8,'2024-02-01',5,6,7,20,12),(59,'ITM0000028','Fenugreek',160.00,180.00,NULL,95.00,10,'2024-02-02',6,7,9,15,13),(60,'ITM0000029','Coriander Seeds',200.00,220.00,NULL,110.00,11,'2024-02-03',7,8,8,12,14),(61,'ITM0000030','Garam Masala',190.00,210.00,NULL,75.00,7,'2024-02-04',8,9,10,16,15),(62,'ITM0000031','Coconut Milk',220.00,240.00,NULL,120.00,12,'2024-02-05',9,10,11,19,16),(63,'ITM0000032','Jasmine Rice',850.00,880.00,NULL,300.00,100,'2024-02-06',10,11,12,13,17),(64,'ITM0000033','Soya Sauce',180.00,200.00,NULL,90.00,100,'2024-02-07',11,1,13,14,18),(65,'ITM0000034','Pickles',220.00,240.00,NULL,80.00,8,'2024-02-08',12,2,12,16,19),(66,'ITM0000035','Sesame Seeds',250.00,270.00,NULL,100.00,10,'2024-02-09',13,3,11,18,20),(67,'ITM0000036','Vermicelli',150.00,170.00,NULL,130.00,13,'2024-02-10',14,4,10,20,21),(68,'ITM0000037','Coconut Chips',180.00,200.00,NULL,140.00,14,'2024-02-11',15,5,9,12,22),(69,'ITM0000038','Tea Bags',300.00,280.00,NULL,205.00,20,'2024-02-12',16,6,8,15,23),(70,'ITM0000039','Pulses Mix',220.00,240.00,NULL,160.00,16,'2024-02-13',17,7,13,18,24),(71,'ITM0000040','Cashew Nuts',400.00,420.00,NULL,50.00,5,'2024-02-14',18,8,12,14,25),(72,'ITM0000041','Rasam Powder',250.00,270.00,NULL,90.00,9,'2024-02-15',19,9,11,16,1),(73,'ITM0000042','Curry Leaves',100.00,120.00,NULL,70.00,7,'2024-02-16',20,10,14,19,2),(74,'ITM0000043','Cooking Oil',350.00,370.00,NULL,110.00,11,'2024-02-17',21,11,13,15,3),(75,'ITM0000044','Honey',500.00,900.00,NULL,62.00,6,'2024-02-18',22,12,12,18,4),(76,'ITM0000045','Milk Powder',280.00,300.00,NULL,140.00,14,'2024-02-19',23,13,11,20,5),(77,'ITM0000046','Oats',590.00,240.00,NULL,80.00,8,'2024-02-20',24,14,10,16,6),(78,'ITM0000047','Corn Flour',150.00,170.00,NULL,130.00,13,'2024-02-21',25,15,9,18,7),(79,'ITM0000048','Basmati Rice',800.00,850.00,NULL,70.00,7,'2024-02-22',26,1,12,15,8),(80,'ITM0000049','Bread',100.00,120.00,NULL,90.00,9,'2024-02-23',27,2,11,12,9),(81,'ITM0000050','Pasta',200.00,220.00,NULL,60.00,6,'2024-02-24',28,3,10,19,10),(82,'ITM0000051','Butter',350.00,370.00,NULL,50.00,5,'2024-02-25',29,4,9,14,11),(83,'ITM0000052','Cheese',450.00,470.00,NULL,40.00,4,'2024-02-26',30,5,8,18,12),(84,'ITM0000053','Ghee',500.00,520.00,NULL,30.00,3,'2024-02-27',31,6,7,20,13),(85,'ITM0000054','Yogurt',150.00,170.00,NULL,110.00,11,'2024-02-28',32,7,10,15,14),(86,'ITM0000055','Sambar Powder',200.00,220.00,NULL,110.00,11,'2024-03-01',33,8,9,18,15),(87,'ITM0000056','Coconut Cream',250.00,270.00,NULL,90.00,9,'2024-03-02',34,9,12,16,16),(88,'ITM0000057','Red Lentils',150.00,170.00,NULL,130.00,13,'2024-03-03',35,10,11,20,17),(89,'ITM0000058','Black Tea',300.00,320.00,NULL,80.00,8,'2024-03-04',36,11,10,19,18),(90,'ITM0000059','Coconut Water',180.00,200.00,NULL,100.00,10,'2024-03-05',37,12,9,15,19),(91,'ITM0000060','Instant Coffee',220.00,240.00,NULL,140.00,14,'2024-03-06',38,13,8,14,20),(92,'ITM0000061','Ginger Candy',250.00,270.00,NULL,70.00,7,'2024-03-07',39,14,12,17,21),(93,'ITM0000062','Chili Sauce',300.00,320.00,NULL,60.00,6,'2024-03-08',40,15,11,19,22),(94,'ITM0000063','Pineapple Jam',150.00,170.00,NULL,120.00,12,'2024-03-09',41,1,9,20,23),(95,'ITM0000064','Cashew Butter',350.00,370.00,NULL,50.00,5,'2024-03-10',42,2,13,15,24),(96,'ITM0000065','Sweet Chili Powder',200.00,220.00,NULL,90.00,9,'2024-03-11',43,3,10,18,25),(97,'ITM0000066','Srilankan Curry Powder',250.00,270.00,NULL,80.00,8,'2024-03-12',44,4,11,14,1),(98,'ITM0000067','Curry Paste',180.00,200.00,NULL,70.00,7,'2024-03-13',45,5,12,16,2),(99,'ITM0000068','Coconut Milk Powder',220.00,240.00,NULL,140.00,14,'2024-03-14',46,6,9,12,3),(100,'ITM0000069','Baking Powder',150.00,170.00,NULL,100.00,10,'2024-03-15',47,7,10,15,4),(101,'ITM0000070','Flour',100.00,120.00,NULL,150.00,15,'2024-03-16',48,8,11,18,5),(102,'ITM0000071','Granulated Sugar',180.00,200.00,NULL,120.00,12,'2024-03-17',49,9,9,16,6),(103,'ITM0000072','Honeycomb',250.00,220.00,NULL,80.00,9,'2024-03-18',50,10,12,14,7),(104,'ITM0000073','Dry Fruits Mix',350.00,370.00,NULL,60.00,6,'2024-03-19',51,11,13,20,8),(105,'ITM0000074','Fruit Preserve',200.00,220.00,NULL,110.00,11,'2024-03-20',52,12,10,19,9),(106,'ITM0000075','Syrup',250.00,270.00,NULL,100.00,10,'2024-03-21',53,13,11,17,10),(107,'ITM0000076','Cheddar Cheese',400.00,420.00,NULL,80.00,8,'2024-03-22',54,14,9,15,11),(108,'ITM0000077','Cream Cheese',450.00,470.00,NULL,70.00,7,'2024-03-23',55,15,10,18,12),(109,'ITM0000078','Butter Milk',300.00,320.00,NULL,90.00,9,'2024-03-24',56,1,12,19,13),(110,'ITM0000079','Sri Lankan Curry Powder',220.00,240.00,NULL,50.00,60,'2024-03-01',1,1,1,1,1),(184,'ITM0000080','Sri Lankan Curry Powder',220.00,240.00,NULL,50.00,60,'2024-03-01',1,1,1,1,1),(185,'ITM0000081','Coconut Oil',300.00,320.00,NULL,40.00,55,'2024-03-02',2,2,2,2,2),(186,'ITM0000082','Spices Pack',150.00,180.00,NULL,45.00,50,'2024-03-03',3,3,3,3,3),(187,'ITM0000083','Dried Fish',200.00,220.00,NULL,35.00,45,'2024-03-04',4,4,4,4,4),(188,'ITM0000084','Jaggery',120.00,130.00,NULL,55.00,65,'2024-03-05',5,5,5,5,5),(189,'ITM0000085','Sambol Mix',250.00,270.00,NULL,70.00,80,'2024-03-06',6,6,6,6,6),(190,'ITM0000086','Cinnamon Sticks',350.00,370.00,NULL,30.00,45,'2024-03-07',7,7,7,7,7),(191,'ITM0000087','Pepper Powder',200.00,220.00,NULL,60.00,70,'2024-03-08',8,8,8,8,8),(192,'ITM0000088','Turmeric Powder',180.00,200.00,NULL,50.00,60,'2024-03-09',9,9,9,9,9),(193,'ITM0000089','Ginger Paste',250.00,270.00,NULL,40.00,55,'2024-03-10',10,10,10,10,10),(194,'ITM0000090','Cardamom',400.00,420.00,NULL,25.00,35,'2024-03-11',11,11,11,11,11),(195,'ITM0000091','Chili Powder',170.00,190.00,NULL,70.00,80,'2024-03-12',12,12,12,12,12),(196,'ITM0000092','Tamarind',140.00,160.00,NULL,45.00,60,'2024-03-13',13,13,13,13,13),(197,'ITM0000093','Mustard Seeds',130.00,150.00,NULL,55.00,65,'2024-03-14',14,14,14,14,14),(198,'ITM0000094','Coriander Seeds',200.00,220.00,NULL,50.00,60,'2024-03-16',16,1,1,1,1),(199,'ITM0000095','Garam Masala',190.00,210.00,NULL,40.00,55,'2024-03-17',17,2,2,2,2),(200,'ITM0000096','Coconut Milk',220.00,240.00,NULL,110.00,75,'2024-03-18',18,3,3,3,3),(201,'ITM0000097','Jasmine Rice',850.00,880.00,NULL,31.00,50,'2024-03-19',19,4,4,4,4),(202,'ITM0000098','Soya Sauce',180.00,200.00,NULL,50.00,65,'2024-03-20',20,5,5,5,5),(203,'ITM0000099','Pickles',220.00,240.00,NULL,55.00,70,'2024-03-21',21,6,6,6,6),(204,'ITM0000100','Sesame Seeds',250.00,270.00,NULL,45.00,60,'2024-03-22',22,7,7,7,7),(205,'ITM0000101','Vermicelli',150.00,170.00,NULL,80.00,90,'2024-03-23',23,8,8,8,8),(206,'ITM0000102','Coconut Chips',180.00,200.00,NULL,50.00,65,'2024-03-24',24,9,9,9,9),(207,'ITM0000103','Tea Bags',300.00,320.00,NULL,40.00,50,'2024-03-25',25,10,10,10,10),(208,'ITM0000104','Pulses Mix',220.00,240.00,NULL,60.00,75,'2024-03-26',26,11,11,11,11),(209,'ITM0000105','Cashew Nuts',400.00,420.00,NULL,35.00,45,'2024-03-27',27,12,12,12,12),(210,'ITM0000106','Rasam Powder',250.00,270.00,NULL,55.00,70,'2024-03-28',28,13,13,13,13),(211,'ITM0000107','Curry Leaves',100.00,120.00,NULL,70.00,80,'2024-03-29',29,14,14,14,14),(212,'ITM0000108','Honey',500.00,900.00,NULL,28.00,35,'2024-03-31',31,1,1,1,1),(213,'ITM0000109','Milk Powder',280.00,300.00,NULL,40.00,55,'2024-04-01',32,2,2,2,2),(214,'ITM0000110','Oats',220.00,240.00,NULL,60.00,75,'2024-04-02',33,3,3,3,3),(215,'ITM0000111','Corn Flour',150.00,170.00,NULL,45.00,60,'2024-04-03',34,4,4,4,4),(216,'ITM0000112','Basmati Rice',800.00,850.00,NULL,30.00,45,'2024-04-04',35,5,5,5,5),(217,'ITM0000113','Bread',100.00,120.00,NULL,80.00,90,'2024-04-05',36,6,6,6,6),(218,'ITM0000114','Pasta',200.00,220.00,NULL,45.00,55,'2024-04-06',37,7,7,7,7),(219,'ITM0000115','Dried Coconut',180.00,200.00,NULL,25.00,40,'2024-04-07',38,8,7,12,14),(220,'ITM0000116','Sweetened Condensed Milk',220.00,240.00,NULL,30.00,50,'2024-04-08',39,9,10,14,15),(221,'ITM0000117','Chili Flakes',220.00,240.00,NULL,25.00,35,'2024-04-09',40,10,11,16,17),(222,'ITM0000118','Vanilla Extract',300.00,320.00,NULL,20.00,30,'2024-04-10',41,11,12,18,18),(223,'ITM0000119','Cashew Nuts',400.00,420.00,NULL,15.00,25,'2024-04-11',42,12,13,20,19),(224,'ITM0000120','Whole Wheat Flour',150.00,170.00,NULL,40.00,55,'2024-04-12',43,13,14,15,20),(225,'ITM0000121','Coconut Vinegar',250.00,270.00,NULL,65.00,50,'2024-04-13',44,14,12,14,21);
/*!40000 ALTER TABLE `Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itembrand`
--

DROP TABLE IF EXISTS `itembrand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itembrand` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itembrand`
--

LOCK TABLES `itembrand` WRITE;
/*!40000 ALTER TABLE `itembrand` DISABLE KEYS */;
INSERT INTO `itembrand` VALUES (1,'Unilever Sri Lanka'),(2,'Hemas Holdings'),(3,'Nestlé Lanka'),(4,'Ceylon Biscuits Limited (CBL)'),(5,'Dilmah'),(6,'Elephant House'),(7,'Maliban'),(8,'Prima'),(9,'MD'),(10,'Keells'),(11,'Pelwatte'),(12,'Anchor'),(13,'Raigam'),(14,'Nipuna'),(15,'Araliya');
/*!40000 ALTER TABLE `itembrand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iteminvoice`
--

DROP TABLE IF EXISTS `iteminvoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iteminvoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Item_id` int NOT NULL,
  `invoice_id` int NOT NULL,
  `linetotal` decimal(9,2) DEFAULT NULL,
  `qty` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Item_has_invoice_invoice1_idx` (`invoice_id`),
  KEY `fk_Item_has_invoice_Item1_idx` (`Item_id`),
  CONSTRAINT `fk_Item_has_invoice_invoice1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`),
  CONSTRAINT `fk_Item_has_invoice_Item1` FOREIGN KEY (`Item_id`) REFERENCES `Item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iteminvoice`
--

LOCK TABLES `iteminvoice` WRITE;
/*!40000 ALTER TABLE `iteminvoice` DISABLE KEYS */;
INSERT INTO `iteminvoice` VALUES (38,4,45,2000.00,2.00),(39,2,46,2000.00,2.00),(40,1,47,0.15,3.00),(41,2,48,3000.00,3.00),(42,41,49,1500.00,3.00),(43,53,50,660.00,3.00),(44,1,51,0.20,4.00),(45,2,52,4000.00,4.00),(46,3,53,20000.00,1.00),(47,4,54,2000.00,2.00),(48,3,55,20000.00,1.00),(49,4,56,2000.00,2.00),(50,2,57,2000.00,2.00),(51,4,58,2000.00,2.00),(52,3,59,40000.00,2.00),(53,3,60,20000.00,1.00),(54,1,61,19000.00,1.00);
/*!40000 ALTER TABLE `iteminvoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itemstatus`
--

DROP TABLE IF EXISTS `itemstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itemstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itemstatus`
--

LOCK TABLES `itemstatus` WRITE;
/*!40000 ALTER TABLE `itemstatus` DISABLE KEYS */;
INSERT INTO `itemstatus` VALUES (1,'Available'),(2,'Out of Stock'),(3,'Backordered'),(4,'Discontinued'),(5,'Pending'),(6,'Reserved'),(7,'Damaged'),(8,'Under Review'),(9,'Returned'),(10,'On Hold'),(11,'Pre-order'),(12,'Recalled'),(13,'In Transit'),(14,'Refurbished');
/*!40000 ALTER TABLE `itemstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyaltyprogram`
--

DROP TABLE IF EXISTS `loyaltyprogram`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loyaltyprogram` (
  `id` int NOT NULL AUTO_INCREMENT,
  `level` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyaltyprogram`
--

LOCK TABLES `loyaltyprogram` WRITE;
/*!40000 ALTER TABLE `loyaltyprogram` DISABLE KEYS */;
INSERT INTO `loyaltyprogram` VALUES (1,'Bronze'),(2,'Silver '),(3,'Gold'),(4,'Platinum'),(5,'Diamond');
/*!40000 ALTER TABLE `loyaltyprogram` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module`
--

LOCK TABLES `module` WRITE;
/*!40000 ALTER TABLE `module` DISABLE KEYS */;
INSERT INTO `module` VALUES (1,'Employee'),(2,'Supplier Payment'),(3,'Supplier Return'),(4,'Purchase Order'),(9,'Supplier'),(10,'User'),(11,'Privilege'),(12,'Operations'),(13,'Customer Registration'),(14,'Customer Payment'),(15,'Customer Return'),(16,'Invoice'),(17,'Income Deposits'),(18,'Vehicle'),(19,'Shop'),(20,'Route'),(21,'Distribution Order'),(22,'Distribution Receives'),(23,'Distribution Request'),(24,'Item'),(25,'Goods Received Note'),(26,'Store'),(27,'Store Return'),(28,'Purchase'),(29,'Sale'),(30,'Distribution'),(31,'Inventory');
/*!40000 ALTER TABLE `module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation`
--

DROP TABLE IF EXISTS `operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `module_id` int DEFAULT NULL,
  `opetype_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_operation_module1_idx` (`module_id`),
  KEY `fk_operation_opetype1_idx` (`opetype_id`),
  CONSTRAINT `fk_operation_module1` FOREIGN KEY (`module_id`) REFERENCES `module` (`id`),
  CONSTRAINT `fk_operation_opetype1` FOREIGN KEY (`opetype_id`) REFERENCES `opetype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation`
--

LOCK TABLES `operation` WRITE;
/*!40000 ALTER TABLE `operation` DISABLE KEYS */;
INSERT INTO `operation` VALUES (1,'Insert',1,1),(2,'Select',1,1),(3,'Update',1,1),(4,'Delete',1,1);
/*!40000 ALTER TABLE `operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opetype`
--

DROP TABLE IF EXISTS `opetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opetype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opetype`
--

LOCK TABLES `opetype` WRITE;
/*!40000 ALTER TABLE `opetype` DISABLE KEYS */;
INSERT INTO `opetype` VALUES (1,'Default'),(2,'Specific');
/*!40000 ALTER TABLE `opetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pnumber` varchar(45) NOT NULL,
  `grandtotal` decimal(10,2) DEFAULT NULL,
  `ptype_id` int NOT NULL,
  `invoice_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_payment_ptype1_idx` (`ptype_id`),
  KEY `fk_payment_invoice1_idx` (`invoice_id`),
  KEY `fk_payment_employee1_idx` (`employee_id`),
  CONSTRAINT `fk_payment_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_payment_invoice1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`),
  CONSTRAINT `fk_payment_ptype1` FOREIGN KEY (`ptype_id`) REFERENCES `ptype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (36,'PAY202407310002',2000.00,1,45,1,'2024-07-31'),(38,'PAY202407310003',2000.00,1,46,2,'2024-07-31'),(39,'PAY202407310004',0.15,1,47,2,'2024-07-31'),(40,'PAY202407310005',3000.00,1,48,2,'2024-07-31'),(41,'PAY202407310006',1500.00,1,49,2,'2024-07-31'),(42,'PAY202407310007',660.00,1,50,3,'2024-07-31'),(43,'PAY202407310008',0.20,1,51,1,'2024-07-31'),(44,'PAY202407310009',4000.00,1,52,1,'2024-07-31'),(45,'PAY202407310010',20000.00,1,53,1,'2024-07-31'),(46,'PAY202407310011',2000.00,2,54,2,'2024-07-31'),(47,'PAY202407310012',20000.00,2,55,1,'2024-07-31'),(48,'PAY202407310013',2000.00,2,56,1,'2024-07-31'),(49,'PAY202407310014',2000.00,1,57,1,'2024-07-31'),(50,'PAY202407310015',2000.00,1,58,1,'2024-07-31'),(51,'PAY202407310016',40000.00,1,59,3,'2024-07-31'),(52,'PAY202407310017',20000.00,2,60,1,'2024-07-31'),(53,'PAY202407310018',19000.00,2,61,4,'2024-07-31');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poitem`
--

DROP TABLE IF EXISTS `poitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Item_id` int NOT NULL,
  `purorder_id` int NOT NULL,
  `qty` int NOT NULL,
  `explinetotal` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Item_has_purorder_purorder1_idx` (`purorder_id`),
  KEY `fk_Item_has_purorder_Item1_idx` (`Item_id`),
  CONSTRAINT `fk_Item_has_purorder_Item1` FOREIGN KEY (`Item_id`) REFERENCES `Item` (`id`),
  CONSTRAINT `fk_Item_has_purorder_purorder1` FOREIGN KEY (`purorder_id`) REFERENCES `purorder` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poitem`
--

LOCK TABLES `poitem` WRITE;
/*!40000 ALTER TABLE `poitem` DISABLE KEYS */;
INSERT INTO `poitem` VALUES (16,1,12,2,2000.00),(17,72,12,2,540.00),(18,110,12,3,720.00),(19,212,12,1,520.00),(20,2,13,1,10.25),(21,73,13,2,240.00),(22,98,13,5,1000.00),(23,74,14,4,1480.00),(24,99,14,3,720.00),(25,214,14,4,960.00),(26,5,15,1000,4990.00),(28,72,16,20,5400.00),(29,1,16,2,2000.00),(30,1,17,2,2000.00),(31,50,18,2,400.00),(32,70,19,5,1200.00),(33,95,19,4,1480.00),(34,48,20,2,740.00),(35,1,21,7,7000.00),(36,188,22,5,650.00),(37,76,22,5,1500.00),(38,72,23,100,27000.00),(46,100,26,4,680.00),(47,75,26,3,1560.00),(48,50,27,3,600.00),(49,71,27,4,1680.00),(50,96,27,1,220.00),(51,26,28,2,599.98),(52,52,28,2,840.00),(53,189,28,2,540.00),(55,99,30,3,720.00),(56,200,30,3,720.00),(57,95,31,5,1850.00),(58,95,29,5,1850.00),(59,212,32,3,1920.00),(60,69,33,5,1600.00),(61,1,34,3,3000.00),(63,3,35,100,200000.00),(64,50,36,40,8000.00);
/*!40000 ALTER TABLE `poitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postatus`
--

DROP TABLE IF EXISTS `postatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `postatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postatus`
--

LOCK TABLES `postatus` WRITE;
/*!40000 ALTER TABLE `postatus` DISABLE KEYS */;
INSERT INTO `postatus` VALUES (1,'Pending'),(2,'Approved'),(7,'Received'),(9,'Invoiced'),(10,'Cancelled'),(11,'Closed');
/*!40000 ALTER TABLE `postatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `privilege` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `module_id` int NOT NULL,
  `operation_id` int NOT NULL,
  `authority` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_privilage_role1_idx` (`role_id`),
  KEY `fk_privilage_module1_idx` (`module_id`),
  KEY `fk_privilage_operation1_idx` (`operation_id`),
  CONSTRAINT `fk_privilage_module1` FOREIGN KEY (`module_id`) REFERENCES `module` (`id`),
  CONSTRAINT `fk_privilage_operation1` FOREIGN KEY (`operation_id`) REFERENCES `operation` (`id`),
  CONSTRAINT `fk_privilage_role1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilege`
--

LOCK TABLES `privilege` WRITE;
/*!40000 ALTER TABLE `privilege` DISABLE KEYS */;
INSERT INTO `privilege` VALUES (1,1,1,1,'employee-insert'),(2,1,1,2,'employee-select'),(3,1,10,1,'user-insert'),(4,2,4,1,'purchase order-insert');
/*!40000 ALTER TABLE `privilege` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pstatus`
--

DROP TABLE IF EXISTS `pstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pstatus`
--

LOCK TABLES `pstatus` WRITE;
/*!40000 ALTER TABLE `pstatus` DISABLE KEYS */;
INSERT INTO `pstatus` VALUES (1,'Pending'),(2,'Approved'),(3,'Paid'),(4,'Cancelled');
/*!40000 ALTER TABLE `pstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ptype`
--

DROP TABLE IF EXISTS `ptype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ptype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ptype`
--

LOCK TABLES `ptype` WRITE;
/*!40000 ALTER TABLE `ptype` DISABLE KEYS */;
INSERT INTO `ptype` VALUES (1,'cash'),(2,'card'),(3,'check');
/*!40000 ALTER TABLE `ptype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purorder`
--

DROP TABLE IF EXISTS `purorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purorder` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ponumber` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `expectedcost` decimal(10,2) NOT NULL,
  `description` text,
  `postatus_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_purorder_postatus1_idx` (`postatus_id`),
  KEY `fk_purorder_employee1_idx` (`employee_id`),
  KEY `fk_purorder_supplier1_idx` (`supplier_id`),
  CONSTRAINT `fk_purorder_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_purorder_postatus1` FOREIGN KEY (`postatus_id`) REFERENCES `postatus` (`id`),
  CONSTRAINT `fk_purorder_supplier1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purorder`
--

LOCK TABLES `purorder` WRITE;
/*!40000 ALTER TABLE `purorder` DISABLE KEYS */;
INSERT INTO `purorder` VALUES (12,'POR202407300001','2024-07-30',3780.00,'sample',1,1,1),(13,'POR202407300002','2024-07-30',1250.25,'sample',1,1,2),(14,'POR202407300003','2024-07-30',3160.00,'sample',1,1,3),(15,'POR202407300004','2024-07-30',4990.00,'sample',1,1,5),(16,'POR202407300005','2024-07-30',7400.00,'sample',1,1,1),(17,'POR202407300006','2024-07-30',2000.00,'sample',1,1,1),(18,'POR202407300007','2024-07-30',400.00,'sample',1,1,25),(19,'POR202407300008','2024-07-30',2680.00,'sample',1,1,24),(20,'POR202407300009','2024-07-30',740.00,'sample',1,1,23),(21,'POR202407300010','2024-07-30',7000.00,'sample',1,1,1),(22,'POR202407300011','2024-07-30',2150.00,'sample',1,1,5),(23,'POR202407300012','2024-07-30',27000.00,'sample',1,1,1),(26,'POR202407310002','2024-07-31',2240.00,'sample',2,1,4),(27,'POR202407310003','2024-07-31',2500.00,'sample',2,1,25),(28,'POR202407310004','2024-07-31',1979.98,'sample',2,1,6),(29,'POR202407310005','2024-07-31',1200.00,'sample',2,1,17),(30,'POR202407310006','2024-07-31',1440.00,'sample',2,1,3),(31,'POR202407310007','2024-07-31',1850.00,'sample',2,1,24),(32,'POR202407310008','2024-07-31',1920.00,'sample',2,1,1),(33,'POR202407310009','2024-07-31',1600.00,'sample',2,1,23),(34,'POR202407310010','2024-07-31',3000.00,'sample',7,1,1),(35,'POR202407310011','2024-07-31',200000.00,'sample',7,1,3),(36,'POR202408010001','2024-08-01',8000.00,'sample',7,1,25);
/*!40000 ALTER TABLE `purorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Admin'),(2,'PurManager'),(3,'SaleManager'),(4,'DisManager'),(5,'InveManager');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `distance` varchar(45) DEFAULT NULL,
  `routenumber` varchar(45) DEFAULT NULL,
  `grade_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_route_grade1_idx` (`grade_id`),
  CONSTRAINT `fk_route_grade1` FOREIGN KEY (`grade_id`) REFERENCES `grade` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES (1,'Ja-Ela to Colombo','25 km','A1',1),(2,'Ja-Ela to Negombo','15 km','A3',1),(3,'Ja-Ela to Katunayake','10 km','A3',1),(4,'Ja-Ela to Minuwangoda','12 km','B123',2),(5,'Ja-Ela to Kandana','8 km','C456',3),(6,'Ja-Ela to Wattala','7 km','B789',2),(7,'Ja-Ela to Gampaha','20 km','A6',1),(8,'Ja-Ela to Kandana via Ragama','10 km','B890',2),(9,'Ja-Ela to Seeduwa','5 km','C321',3),(10,'Ja-Ela to Ekala','6 km','C654',3),(11,'Ja-Ela to Ganemulla','12 km','B432',2),(12,'Ja-Ela to Veyangoda','18 km','A5',1),(13,'Ja-Ela to Kochchikade','25 km','B1234',2),(14,'Ja-Ela to Pamunugama','8 km','C987',3),(15,'Ja-Ela to Peliyagoda','20 km','A3',1),(16,'Ja-Ela to Thudella','3 km','D567',5),(17,'Ja-Ela to Kapuwatta','4 km','D890',5),(18,'Ja-Ela to Bolawalana','12 km','B234',2),(19,'Ja-Ela to Kanuwana','2 km','D678',5),(20,'Ja-Ela to Ragama','9 km','C456',3),(21,'Ja-Ela to Negombo','15 km','A3',1),(22,'Ja-Ela to Katunayake','10 km','A3',1),(24,'Ja-Ela to Kandana','8 km','C456',3),(25,'Ja-Ela to Ganemulla','12 km','B432',2),(26,'Ja-Ela to Veyangoda','18 km','A5',1),(27,'Ja-Ela to Kochchikade','25 km','B1234',2),(28,'Ja-Ela to Pamunugama','8 km','C987',3),(29,'Ja-Ela to Peliyagoda','20 km','A3',1),(30,'Ja-Ela to Thudella','3 km','D567',5),(31,'Ja-Ela to Kapuwatta','4 km','D890',5),(32,'Ja-Ela to Bolawalana','12 km','B234',2),(33,'Ja-Ela to Kanuwana','2 km','D678',5);
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop`
--

DROP TABLE IF EXISTS `shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shopnumber` varchar(45) DEFAULT NULL,
  `address` text,
  `cnumber` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `opdate` varchar(45) DEFAULT NULL,
  `shopstatus_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `route_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_shop_shopstatus1_idx` (`shopstatus_id`),
  KEY `fk_shop_employee1_idx` (`employee_id`),
  KEY `fk_shop_route1_idx` (`route_id`),
  CONSTRAINT `fk_shop_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_shop_route1` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`),
  CONSTRAINT `fk_shop_shopstatus1` FOREIGN KEY (`shopstatus_id`) REFERENCES `shopstatus` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop`
--

LOCK TABLES `shop` WRITE;
/*!40000 ALTER TABLE `shop` DISABLE KEYS */;
INSERT INTO `shop` VALUES (1,'123','123 Main St','1234567890','shop@example.com','2024-07-17',1,5,1),(2,'456','456 Elm St','9876543210','another_shop@example.com','2024-07-18',2,6,2),(3,'790','789 Oak St','1112223333','third_shop@example.com','2024-07-19',3,7,1),(4,'123','123 Main St','123-456-7890','shop@example.com','2024-07-17',1,8,3),(5,'457','456 Elm St','0778488242','another_shop@example.com','2024-07-18',2,9,4),(6,'789','789 Oak St','111-222-3333','third_shop@example.com','2024-07-19',3,10,5),(7,'123','123 Main St','123-456-7890','nmshop@example.com','2024-07-17',1,11,6),(8,'459','456 Elm St','0771234567','elevent_shop@example.com','2024-07-18',1,12,7),(9,'800','789 Oak St','2222266771','tk_shop@example.com','2024-07-19',3,13,8),(10,'234','234 Pine St','222-333-4444','fourth_shop@example.com','2024-07-20',1,14,9),(11,'567','567 Maple St','555-666-7777','fifth_shop@example.com','2024-07-21',2,15,10),(12,'890','890 Cedar St','888-999-0000','sixth_shop@example.com','2024-07-22',3,16,10),(13,'111','111 Walnut St','1231231231','seventh_shop@example.com','2024-07-23',1,17,1),(14,'222','222 Birch St','777-888-9999','eighth_shop@example.com','2024-07-24',2,18,12),(15,'333','333 Sycamore St','333-444-5555','ninth_shop@example.com','2024-07-25',3,19,13),(16,'444','444 Oak St','444-555-6666','tenth_shop@example.com','2024-07-26',1,20,14),(17,'122','123 Main St','1234567890','shop@example.com','2024-07-17',1,5,15),(19,'100','123 Main St','1234567890','shop@example.com','2024-07-17',1,5,15),(20,'199','123 Main St','1234567890','shop@example.com','2024-07-17',1,5,16);
/*!40000 ALTER TABLE `shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopstatus`
--

DROP TABLE IF EXISTS `shopstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shopstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopstatus`
--

LOCK TABLES `shopstatus` WRITE;
/*!40000 ALTER TABLE `shopstatus` DISABLE KEYS */;
INSERT INTO `shopstatus` VALUES (1,'open'),(2,'closed'),(3,'renovation');
/*!40000 ALTER TABLE `shopstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sritem`
--

DROP TABLE IF EXISTS `sritem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sritem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qty` decimal(6,2) DEFAULT NULL,
  `storereturn_id` int NOT NULL,
  `Item_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sritem_storereturn1_idx` (`storereturn_id`),
  KEY `fk_sritem_Item1_idx` (`Item_id`),
  CONSTRAINT `fk_sritem_Item1` FOREIGN KEY (`Item_id`) REFERENCES `Item` (`id`),
  CONSTRAINT `fk_sritem_storereturn1` FOREIGN KEY (`storereturn_id`) REFERENCES `storereturn` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sritem`
--

LOCK TABLES `sritem` WRITE;
/*!40000 ALTER TABLE `sritem` DISABLE KEYS */;
INSERT INTO `sritem` VALUES (2,20.00,3,1);
/*!40000 ALTER TABLE `sritem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storenumber` varchar(45) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `esdate` date DEFAULT NULL,
  `cnumber` char(10) DEFAULT NULL,
  `email` text,
  `employee_id` int NOT NULL,
  `route_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_store_employee1_idx` (`employee_id`),
  KEY `fk_store_route1_idx` (`route_id`),
  CONSTRAINT `fk_store_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_store_route1` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES (1,'S001','123 Main Street, Ja-Ela','2020-05-15','1234567890','test@email.com',1,1),(2,'S002','456 Elm Avenue, Ja-Ela','2019-10-20','9876543210','test1@email.com',2,1),(3,'S003','789 Oak Road, Ja-Ela','2021-03-08','5551234567','test2@email.com',3,1),(4,'S004','321 Pine Boulevard, Ja-Ela','2022-01-10','1112223333','test3@email.com',4,1);
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storereturn`
--

DROP TABLE IF EXISTS `storereturn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storereturn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `description` text,
  `employee_id` int NOT NULL,
  `store_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_storereturn_employee1_idx` (`employee_id`),
  KEY `fk_storereturn_store1_idx` (`store_id`),
  CONSTRAINT `fk_storereturn_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_storereturn_store1` FOREIGN KEY (`store_id`) REFERENCES `store` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storereturn`
--

LOCK TABLES `storereturn` WRITE;
/*!40000 ALTER TABLE `storereturn` DISABLE KEYS */;
INSERT INTO `storereturn` VALUES (3,'2024-08-01','sample',1,1);
/*!40000 ALTER TABLE `storereturn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcategory`
--

DROP TABLE IF EXISTS `subcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcategory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `category_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_subcategory_category1_idx` (`category_id`),
  CONSTRAINT `fk_subcategory_category1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategory`
--

LOCK TABLES `subcategory` WRITE;
/*!40000 ALTER TABLE `subcategory` DISABLE KEYS */;
INSERT INTO `subcategory` VALUES (1,'Smartphones',1),(2,'Laptops',1),(3,'Sofas',2),(4,'Beds',2),(5,'Men\'s Clothing',3),(6,'Women\'s Clothing',3),(7,'Snacks',4),(8,'Beverages',4),(9,'Car Accessories',5),(10,'Motorcycle Accessories',5),(11,'Skincare',6),(12,'Haircare',6),(13,'Fitness Equipment',7),(14,'Outdoor Gear',7),(15,'Fiction',8),(16,'Non-fiction',8),(17,'Action Figures',9),(18,'Dolls',9),(19,'Refrigerators',10),(20,'Washing Machines',10),(21,'Necklaces',11),(22,'Rings',11),(23,'Notebooks',12),(24,'Pens',12),(25,'Garden Furniture',13),(26,'Outdoor Lighting',13),(27,'Pet Food',14),(28,'Pet Toys',14),(29,'Office Chairs',15),(30,'Office Desks',15),(31,'Guitars',16),(32,'Keyboards',16),(33,'Baby Food',17),(34,'Baby Toys',17),(35,'Fresh Produce',18),(36,'Canned Goods',18),(37,'Men\'s Footwear',19),(38,'Women\'s Footwear',19),(39,'Backpacks',20),(40,'Suitcases',20),(41,'Wall Art',21),(42,'Vases',21),(43,'Indoor Lighting',22),(44,'Outdoor Lighting',22),(45,'Bricks',23),(46,'Cement',23),(47,'Hand Tools',24),(48,'Power Tools',24),(49,'Detergents',25),(50,'Cleaning Cloths',25),(51,'Over-the-counter Medicines',26),(52,'Prescription Medicines',26),(53,'Makeup',27),(54,'Fragrances',27),(55,'Surveillance Systems',28),(56,'Safety Alarms',28),(57,'Painting Supplies',29),(58,'Sewing Supplies',29),(59,'Party Decorations',30),(60,'Party Favors',30);
/*!40000 ALTER TABLE `subcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supayment`
--

DROP TABLE IF EXISTS `supayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supayment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `suppayno` varchar(45) NOT NULL,
  `grandtotal` decimal(10,2) DEFAULT NULL,
  `supplier_id` int NOT NULL,
  `grn_id` int NOT NULL,
  `ptype_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `pstatus_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_supayment_supplier1_idx` (`supplier_id`),
  KEY `fk_supayment_grn1_idx` (`grn_id`),
  KEY `fk_supayment_ptype1_idx` (`ptype_id`),
  KEY `fk_supayment_employee1_idx` (`employee_id`),
  KEY `fk_supayment_pstatus1_idx` (`pstatus_id`),
  CONSTRAINT `fk_supayment_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_supayment_grn1` FOREIGN KEY (`grn_id`) REFERENCES `grn` (`id`),
  CONSTRAINT `fk_supayment_pstatus1` FOREIGN KEY (`pstatus_id`) REFERENCES `pstatus` (`id`),
  CONSTRAINT `fk_supayment_ptype1` FOREIGN KEY (`ptype_id`) REFERENCES `ptype` (`id`),
  CONSTRAINT `fk_supayment_supplier1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supayment`
--

LOCK TABLES `supayment` WRITE;
/*!40000 ALTER TABLE `supayment` DISABLE KEYS */;
INSERT INTO `supayment` VALUES (6,'SAY202408010002',560.00,23,29,3,1,2);
/*!40000 ALTER TABLE `supayment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `registernumber` varchar(20) DEFAULT NULL,
  `doregister` date DEFAULT NULL,
  `address` text,
  `officetp` char(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contactperson` varchar(45) DEFAULT NULL,
  `contactnumber` char(10) DEFAULT NULL,
  `description` text,
  `doenter` date DEFAULT NULL,
  `supplierstatus_id` int NOT NULL,
  `supplierstype_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_supplier_supplierstatus1_idx` (`supplierstatus_id`),
  KEY `fk_supplier_supplierstype1_idx` (`supplierstype_id`),
  CONSTRAINT `fk_supplier_supplierstatus1` FOREIGN KEY (`supplierstatus_id`) REFERENCES `supplierstatus` (`id`),
  CONSTRAINT `fk_supplier_supplierstype1` FOREIGN KEY (`supplierstype_id`) REFERENCES `supplierstype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'ABC Manufacturing','REG123456','2023-01-15','123 Industrial Ave, Factory City, FC 12345','1234567890','contact@abcmanufacturing.com','John Doe','0987654321','Supplier of industrial parts','2024-01-01',1,1),(2,'XYZ Distributors','REG654321','2022-11-10','456 Commerce St, Distribution City, DC 54321','2345678901','info@xyzdistributors.com','Jane Smith','1234567890','Wholesale distributor of consumer electronics','2024-02-01',2,2),(3,'Global Traders','REG112233','2021-05-20','789 Trade Blvd, Trading City, TC 67890','3456789012','support@globaltraders.com','Michael Brown','2345678901','Exporter of agricultural products','2024-03-01',3,3),(4,'Tech Solutions','REG334455','2020-07-25','101 Innovation Dr, Tech City, TC 10101','4567890123','sales@techsolutions.com','Emily Davis','3456789012','Supplier of software solutions','2024-04-01',4,4),(5,'Fresh Foods Inc.','REG667788','2019-09-30','202 Fresh St, Food City, FC 20202','5678901234','contact@freshfoods.com','David Wilson','4567890123','Provider of organic food products','2024-05-01',5,5),(6,'EcoGreen Supplies','REG998877','2021-03-12','303 Green Way, Eco City, EC 30303','6789012345','info@ecogreensupplies.com','Anna Green','5678901234','Supplier of eco-friendly products','2024-06-01',6,6),(7,'Office Essentials','REG445566','2020-08-19','404 Office Park, Business City, BC 40404','7890123456','contact@officeessentials.com','Peter Parker','6789012345','Provider of office supplies','2024-07-01',7,7),(8,'Pet Paradise','REG223344','2019-11-05','505 Pet Lane, Pet City, PC 50505','8901234567','support@petparadise.com','Mary Johnson','7890123456','Supplier of pet products','2024-08-01',8,6),(9,'Home Comforts','REG778899','2018-06-15','606 Comfort Dr, Home City, HC 60606','9012345678','sales@homecomforts.com','Lucas Martin','8901234567','Provider of home furniture and decor','2024-09-01',9,5),(10,'Sports Gear Pro','REG990011','2017-04-22','707 Sports Ave, Sports City, SC 70707','0123456789','info@sportsgearpro.com','Sophia Lee','9012345678','Supplier of sports equipment','2024-10-01',10,1),(11,'Bright Lighting','REG776655','2016-12-10','808 Light St, Lighting City, LC 80808','1234567890','contact@brightlighting.com','Nathan King','0123456789','Provider of lighting solutions','2024-11-01',1,4),(12,'Fashion Forward','REG554433','2015-09-18','909 Fashion Blvd, Fashion City, FC 90909','2345678901','support@fashionforward.com','Chloe Taylor','1234567890','Supplier of clothing and accessories','2024-12-01',2,3),(13,'Tool Time','REG332211','2014-07-29','1010 Tool Rd, Tool City, TC 101010','3456789012','sales@tooltime.com','Jack Anderson','2345678901','Provider of tools and hardware','2025-01-01',3,2),(14,'Garden Fresh','REG110099','2013-03-16','1111 Garden Ln, Garden City, GC 11111','4567890123','info@gardenfresh.com','Olivia Thomas','3456789012','Supplier of garden and outdoor products','2025-02-01',4,1),(15,'Safe & Secure','REG667788','2012-05-21','1212 Secure Ave, Secure City, SC 121212','5678901234','contact@safeandsecure.com','Liam Jackson','4567890123','Provider of security solutions','2025-03-01',5,1),(16,'Luxury Linens','REG112244','2011-11-09','1313 Linen Blvd, Textile City, TC 131313','6789012345','info@luxurylinens.com','Emma White','5678901234','Supplier of high-quality linens','2025-04-01',6,1),(17,'Tech Innovators','REG223355','2010-08-23','1414 Innovation St, Tech City, TC 141414','7890123456','contact@techinnovators.com','William Harris','6789012345','Provider of cutting-edge technology solutions','2025-05-01',7,1),(18,'Green Thumb','REG334466','2009-07-15','1515 Green Ave, Plant City, PC 151515','8901234567','support@greenthumb.com','Sophia Clark','7890123456','Supplier of gardening tools and supplies','2025-06-01',8,1),(19,'Culinary Creations','REG445577','2008-06-20','1616 Culinary Ln, Food City, FC 161616','9012345678','sales@culinarycreations.com','James Lewis','8901234567','Provider of gourmet food products','2025-07-01',9,1),(20,'Fitness Fanatics','REG556688','2007-05-12','1717 Fitness Rd, Health City, HC 171717','0123456789','info@fitnessfanatics.com','Ava Walker','9012345678','Supplier of fitness equipment and accessories','2025-08-01',10,2),(21,'Artisan Crafts','REG667799','2006-04-18','1818 Craft Blvd, Art City, AC 181818','1234567890','contact@artisancrafts.com','Mason Young','0123456789','Provider of handmade crafts and materials','2025-09-01',1,1),(22,'Pharma Health','REG778800','2005-03-14','1919 Health St, Pharma City, PC 191919','2345678901','support@pharmahealth.com','Charlotte Scott','1234567890','Supplier of pharmaceuticals and medical supplies','2025-10-01',2,2),(23,'Auto Parts Plus','REG889911','2004-02-22','2020 Auto Dr, Motor City, MC 202020','3456789012','sales@autopartsplus.com','Benjamin Hall','2345678901','Provider of automotive parts and accessories','2025-11-01',3,3),(24,'Bright Futures','REG990022','2003-01-10','2121 Future Ln, Education City, EC 212121','4567890123','info@brightfutures.com','Amelia Baker','3456789012','Supplier of educational materials and supplies','2025-12-01',4,4),(25,'Elegant Events','REG101010','2002-09-25','2222 Event Blvd, Celebration City, CC 222222','5678901234','contact@elegantevents.com','Elijah Campbell','4567890123','Provider of event planning services and supplies','2026-01-01',5,5),(26,'Sandeepa','REG000006','2024-08-02','292.sample','0000000000','sample@in.in','Saman','0778488242','hi','2024-08-02',1,1),(27,'Sandeeepa','REG120000','2024-08-02','Sample','0778488242','sample@1234.in','Sandeepa','0778488242','hi','2024-08-02',1,1),(28,'Jon Stewart Doe','REG123000','2024-08-02','1600 Amphitheatre Parkway','0774888232','test@example.us','Jon Stewart Doe','0778488242','sa','2024-08-01',1,1);
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplierstatus`
--

DROP TABLE IF EXISTS `supplierstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplierstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplierstatus`
--

LOCK TABLES `supplierstatus` WRITE;
/*!40000 ALTER TABLE `supplierstatus` DISABLE KEYS */;
INSERT INTO `supplierstatus` VALUES (1,'Active'),(2,'Inactive'),(3,'Pending Approval'),(4,'Approved'),(5,'Rejected'),(6,'Suspended'),(7,'Blacklisted'),(8,'Under Review'),(9,'Onboarding'),(10,'Terminated');
/*!40000 ALTER TABLE `supplierstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplierstype`
--

DROP TABLE IF EXISTS `supplierstype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplierstype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplierstype`
--

LOCK TABLES `supplierstype` WRITE;
/*!40000 ALTER TABLE `supplierstype` DISABLE KEYS */;
INSERT INTO `supplierstype` VALUES (1,'Manufacturer'),(2,'Distributor'),(3,'Wholesaler'),(4,'Retailer'),(5,'Service Provider'),(6,'Importer'),(7,'Exporter');
/*!40000 ALTER TABLE `supplierstype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supply`
--

DROP TABLE IF EXISTS `supply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supply` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_supply_category1_idx` (`category_id`),
  KEY `fk_supply_supplier1_idx` (`supplier_id`),
  CONSTRAINT `fk_supply_category1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `fk_supply_supplier1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supply`
--

LOCK TABLES `supply` WRITE;
/*!40000 ALTER TABLE `supply` DISABLE KEYS */;
INSERT INTO `supply` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,7,7),(8,8,8),(9,9,9),(10,10,10),(11,11,11),(12,12,12),(13,13,13),(14,14,14),(15,15,15),(16,16,16),(17,17,17),(18,18,18),(19,19,19),(20,20,20),(21,21,21),(22,22,22),(23,23,23),(24,24,24),(25,25,25),(26,26,1),(27,27,2),(28,28,3),(29,29,4),(30,30,5),(31,1,28),(32,2,28),(35,1,2),(36,3,4),(37,5,6),(38,7,8),(39,9,10),(40,11,12),(41,13,14),(42,15,16),(43,17,18),(44,19,20),(45,1,2),(46,3,4),(47,5,6),(48,7,8),(49,9,10);
/*!40000 ALTER TABLE `supply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supreitem`
--

DROP TABLE IF EXISTS `supreitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supreitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supreturn_id` int NOT NULL,
  `Item_id` int NOT NULL,
  `qty` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_supreturn_has_Item_Item1_idx` (`Item_id`),
  KEY `fk_supreturn_has_Item_supreturn1_idx` (`supreturn_id`),
  CONSTRAINT `fk_supreturn_has_Item_Item1` FOREIGN KEY (`Item_id`) REFERENCES `Item` (`id`),
  CONSTRAINT `fk_supreturn_has_Item_supreturn1` FOREIGN KEY (`supreturn_id`) REFERENCES `supreturn` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supreitem`
--

LOCK TABLES `supreitem` WRITE;
/*!40000 ALTER TABLE `supreitem` DISABLE KEYS */;
INSERT INTO `supreitem` VALUES (9,7,50,10);
/*!40000 ALTER TABLE `supreitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supreturn`
--

DROP TABLE IF EXISTS `supreturn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supreturn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `returnno` varchar(45) NOT NULL,
  `reason` text,
  `grandtotal` decimal(10,2) DEFAULT NULL,
  `grn_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `employee_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_supreturn_grn1_idx` (`grn_id`),
  KEY `fk_supreturn_supplier1_idx` (`supplier_id`),
  KEY `fk_supreturn_employee1_idx` (`employee_id`),
  CONSTRAINT `fk_supreturn_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_supreturn_grn1` FOREIGN KEY (`grn_id`) REFERENCES `grn` (`id`),
  CONSTRAINT `fk_supreturn_supplier1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supreturn`
--

LOCK TABLES `supreturn` WRITE;
/*!40000 ALTER TABLE `supreturn` DISABLE KEYS */;
INSERT INTO `supreturn` VALUES (7,'2024-08-01','RET202408010002','sample',3300.00,33,25,5);
/*!40000 ALTER TABLE `supreturn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unittype`
--

DROP TABLE IF EXISTS `unittype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unittype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unittype`
--

LOCK TABLES `unittype` WRITE;
/*!40000 ALTER TABLE `unittype` DISABLE KEYS */;
INSERT INTO `unittype` VALUES (1,'Piece'),(2,'Box'),(3,'Kilogram'),(4,'Gram'),(5,'Liter'),(6,'Milliliter'),(7,'Meter'),(8,'Centimeter'),(9,'Inch'),(10,'Pack'),(11,'Dozen'),(12,'Case'),(13,'Pound'),(14,'Ounce'),(15,'Gallon'),(16,'Square Meter'),(17,'Cubic Meter'),(18,'Yard'),(19,'Roll'),(20,'Bag');
/*!40000 ALTER TABLE `unittype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `docreated` date DEFAULT NULL,
  `tocreated` time DEFAULT NULL,
  `description` text,
  `usestatus_id` int NOT NULL,
  `usetype_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_usestatus1_idx` (`usestatus_id`),
  KEY `fk_user_employee1_idx` (`employee_id`),
  KEY `fk_user_usetype1_idx` (`usetype_id`),
  CONSTRAINT `fk_user_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_user_usestatus1` FOREIGN KEY (`usestatus_id`) REFERENCES `usestatus` (`id`),
  CONSTRAINT `fk_user_usetype1` FOREIGN KEY (`usetype_id`) REFERENCES `usetype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,1,'AdminJohn','$2a$10$GxT2r5PCFmd8JAebVf.7D.GbdtQlzKc/NOvaZtFajDCnvokZ6Pj4.','$2a$10$aPtAl/sDhxkJBJyMhi/ry.IcfTRsuq5hhvbKgBWa4e1/YeR08YkQu','2024-08-01','02:48:47','AdminJohn@1234',1,1),(2,2,'PurJane','$2a$10$/SgbhPNxYNm1t2nJGAJ1GesfWeJWR3ZMobY5VVUQhx66qzep.5siK','$2a$10$VeCRW6uDg6moKFM4hoKp9eC66IIIOBl0dlcQ25Fupi3MMjXF1FAtO','2024-08-03','12:40:22','PurJane123',1,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userrole` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_has_role_role1_idx` (`role_id`),
  KEY `fk_user_has_role_user1_idx` (`user_id`),
  CONSTRAINT `fk_user_has_role_role1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `fk_user_has_role_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userrole`
--

LOCK TABLES `userrole` WRITE;
/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` VALUES (1,1,1),(2,2,2);
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usestatus`
--

DROP TABLE IF EXISTS `usestatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usestatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usestatus`
--

LOCK TABLES `usestatus` WRITE;
/*!40000 ALTER TABLE `usestatus` DISABLE KEYS */;
INSERT INTO `usestatus` VALUES (1,'Assigned'),(2,'Unassigned'),(3,'Suspended'),(4,'Resignated');
/*!40000 ALTER TABLE `usestatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usetype`
--

DROP TABLE IF EXISTS `usetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usetype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usetype`
--

LOCK TABLES `usetype` WRITE;
/*!40000 ALTER TABLE `usetype` DISABLE KEYS */;
INSERT INTO `usetype` VALUES (1,'Permanent'),(2,'Contract ');
/*!40000 ALTER TABLE `usetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicle`
--

DROP TABLE IF EXISTS `vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle` (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` varchar(45) NOT NULL,
  `doattach` date DEFAULT NULL,
  `yom` int DEFAULT NULL,
  `capacity` int NOT NULL,
  `description` text,
  `poto` longblob,
  `curentmeterreading` int NOT NULL,
  `lastregdate` date NOT NULL,
  `lastservicedate` date NOT NULL,
  `vehiclestatus_id` int NOT NULL,
  `vehicletype_id` int NOT NULL,
  `vehiclemodel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vehicle_vehiclestatus1_idx` (`vehiclestatus_id`),
  KEY `fk_vehicle_vehicletype1_idx` (`vehicletype_id`),
  KEY `fk_vehicle_vehiclemodel1_idx` (`vehiclemodel_id`),
  CONSTRAINT `fk_vehicle_vehiclemodel1` FOREIGN KEY (`vehiclemodel_id`) REFERENCES `vehiclemodel` (`id`),
  CONSTRAINT `fk_vehicle_vehiclestatus1` FOREIGN KEY (`vehiclestatus_id`) REFERENCES `vehiclestatus` (`id`),
  CONSTRAINT `fk_vehicle_vehicletype1` FOREIGN KEY (`vehicletype_id`) REFERENCES `vehicletype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle`
--

LOCK TABLES `vehicle` WRITE;
/*!40000 ALTER TABLE `vehicle` DISABLE KEYS */;
INSERT INTO `vehicle` VALUES (1,'ABC1234','2023-01-01',2022,5,'Sample description 1',NULL,5000,'2023-01-01','2023-01-01',1,1,1),(2,'DEF4567','2023-02-01',2021,8,'Sample description 2',NULL,8000,'2023-02-01','2023-02-01',1,1,2),(3,'GHI7891','2023-03-01',2020,10,'Sample description 3',NULL,10000,'2023-03-01','2023-03-01',1,2,3),(4,'JKL0121','2023-04-01',2019,12,'Sample description 4',NULL,12000,'2023-04-01','2023-04-01',1,2,4),(5,'MNO3451','2023-05-01',2018,15,'Sample description 5',NULL,15000,'2023-05-01','2023-05-01',1,3,5),(6,'PQR6781','2023-06-01',2017,18,'Sample description 6',NULL,18000,'2023-06-01','2023-06-01',1,3,6),(7,'STU9011','2023-07-01',2016,20,'Sample description 7',NULL,20000,'2023-07-01','2023-07-01',1,4,7),(8,'VWX2341','2023-08-01',2015,22,'Sample description 8',NULL,22000,'2023-08-01','2023-08-01',1,4,8),(9,'YZA5671','2023-09-01',2014,25,'Sample description 9',NULL,25000,'2023-09-01','2023-09-01',1,5,9),(10,'BCD8901','2023-10-01',2013,28,'Sample description 10',NULL,28000,'2023-10-01','2023-10-01',1,5,10),(11,'EFG1231','2023-11-01',2012,30,'Sample description 11',NULL,30000,'2023-11-01','2023-11-01',1,6,11),(12,'HIJ4561','2023-12-01',2011,35,'Sample description 12',NULL,35000,'2023-12-01','2023-12-01',1,6,12),(13,'KLM7891','2024-01-01',2010,40,'Sample description 13',NULL,40000,'2024-01-01','2024-01-01',1,7,13),(14,'NOP0121','2024-02-01',2009,45,'Sample description 14',NULL,45000,'2024-02-01','2024-02-01',1,7,14),(15,'QRS3451','2024-03-01',2008,50,'Sample description 15',NULL,50000,'2024-03-01','2024-03-01',5,8,1),(16,'TUV6781','2024-04-01',2007,55,'Sample description 16',NULL,55000,'2024-04-01','2024-04-01',2,8,2),(17,'WXY9011','2024-05-01',2006,60,'Sample description 17',NULL,60000,'2024-05-01','2024-05-01',2,9,3),(18,'ZAB2341','2024-06-01',2005,65,'Sample description 18',NULL,65000,'2024-06-01','2024-06-01',2,9,4),(19,'CDE5671','2024-07-01',2004,70,'Sample description 19',NULL,70000,'2024-07-01','2024-07-01',2,10,5),(20,'FGH8901','2024-08-01',2003,75,'Sample description 20',NULL,75000,'2024-08-01','2024-08-01',5,10,6),(21,'ABC1231','2024-07-21',2022,50,'Description of the vehicle',NULL,1000,'2024-05-01','2024-05-15',2,10,15),(72,'ABC0011','2024-01-01',2021,50,'Vehicle 001 description',NULL,1000,'2023-12-01','2023-12-15',1,1,1),(73,'ABC0021','2024-01-02',2022,55,'Vehicle 002 description',NULL,1200,'2023-12-02','2023-12-16',2,2,2),(74,'ABC0031','2024-01-03',2023,60,'Vehicle 003 description',NULL,1300,'2023-12-03','2023-12-17',2,3,3),(75,'ABC0041','2024-01-04',2022,65,'Vehicle 004 description',NULL,1400,'2023-12-04','2023-12-18',4,4,4),(76,'ABC0051','2024-01-05',2021,70,'Vehicle 005 description',NULL,1500,'2023-12-05','2023-12-19',3,5,5),(77,'ABC0061','2024-01-06',2022,55,'Vehicle 006 description',NULL,1600,'2023-12-06','2023-12-20',1,6,6),(78,'ABC0071','2024-01-07',2023,60,'Vehicle 007 description',NULL,1700,'2023-12-07','2023-12-21',2,7,7),(79,'ABC0081','2024-01-08',2022,65,'Vehicle 008 description',NULL,1800,'2023-12-08','2023-12-22',3,8,8),(80,'ABC0091','2024-01-09',2021,70,'Vehicle 009 description',NULL,1900,'2023-12-09','2023-12-23',4,9,9),(81,'ABC0101','2024-01-10',2022,75,'Vehicle 010 description',NULL,2000,'2023-12-10','2023-12-24',2,10,10),(82,'SSD1234','2024-01-11',2023,80,'Vehicle 011 description',NULL,2100,'2023-12-11','2023-12-25',1,11,11),(83,'ABC0122','2024-01-12',2021,85,'Vehicle 012 description',NULL,2200,'2023-12-12','2023-12-26',2,12,12),(84,'ABC0132','2024-01-13',2022,90,'Vehicle 013 description',NULL,2300,'2023-12-13','2023-12-27',3,13,13),(85,'ABC0142','2024-01-14',2023,95,'Vehicle 014 description',NULL,2400,'2023-12-14','2023-12-28',4,14,14),(86,'ABC0152','2024-01-15',2021,100,'Vehicle 015 description',NULL,2500,'2023-12-15','2023-12-29',3,15,15),(87,'ABC0162','2024-01-16',2022,105,'Vehicle 016 description',NULL,2600,'2023-12-16','2023-12-30',1,16,16),(88,'ABC0172','2024-01-17',2023,110,'Vehicle 017 description',NULL,2700,'2023-12-17','2023-12-31',2,17,17),(89,'ABC0182','2024-01-18',2021,115,'Vehicle 018 description',NULL,2800,'2023-12-18','2024-01-01',3,18,18),(90,'ABC0192','2024-01-19',2022,120,'Vehicle 019 description',NULL,2900,'2023-12-19','2024-01-02',4,19,19),(91,'ABC0202','2024-01-20',2023,125,'Vehicle 020 description',NULL,3000,'2023-12-20','2024-01-03',3,20,20),(132,'ABC0212','2024-01-21',2021,130,'Vehicle 021 description',NULL,3100,'2023-12-21','2024-01-04',1,1,1),(133,'ABC0222','2024-01-22',2022,135,'Vehicle 022 description',NULL,3200,'2023-12-22','2024-01-05',2,2,2),(134,'ABC0232','2024-01-23',2023,140,'Vehicle 023 description',NULL,3300,'2023-12-23','2024-01-06',3,3,3),(135,'ABC0242','2024-01-24',2021,145,'Vehicle 024 description',NULL,3400,'2023-12-24','2024-01-07',4,4,4),(136,'ABC0252','2024-01-25',2022,150,'Vehicle 025 description',NULL,3500,'2023-12-25','2024-01-08',5,5,5),(137,'ABC0262','2024-01-26',2023,155,'Vehicle 026 description',NULL,3600,'2023-12-26','2024-01-09',1,6,6),(138,'ABC0272','2024-01-27',2021,160,'Vehicle 027 description',NULL,3700,'2023-12-27','2024-01-10',2,1,1),(139,'ABC0282','2024-01-28',2022,165,'Vehicle 028 description',NULL,3800,'2023-12-28','2024-01-11',3,2,2),(140,'ABC0292','2024-01-29',2023,170,'Vehicle 029 description',NULL,3900,'2023-12-29','2024-01-12',4,3,3),(141,'ABC0302','2024-01-30',2021,175,'Vehicle 030 description',NULL,4000,'2023-12-30','2024-01-13',5,4,4),(142,'ABC0312','2024-01-31',2022,180,'Vehicle 031 description',NULL,4100,'2024-01-01','2024-01-14',1,5,5),(143,'ABC0322','2024-02-01',2023,185,'Vehicle 032 description',NULL,4200,'2024-01-02','2024-01-15',2,6,6),(144,'ABC0332','2024-02-02',2021,190,'Vehicle 033 description',NULL,4300,'2024-01-03','2024-01-16',3,7,7),(145,'ABC0342','2024-02-03',2022,195,'Vehicle 034 description',NULL,4400,'2024-01-04','2024-01-17',4,8,8),(146,'ABC0352','2024-02-04',2023,200,'Vehicle 035 description',NULL,4500,'2024-01-05','2024-01-18',5,9,9),(147,'ABC0362','2024-02-05',2021,205,'Vehicle 036 description',NULL,4600,'2024-01-06','2024-01-19',1,10,10),(148,'ABC0372','2024-02-06',2022,210,'Vehicle 037 description',NULL,4700,'2024-01-07','2024-01-20',2,11,11),(149,'ABC0382','2024-02-07',2023,215,'Vehicle 038 description',NULL,4800,'2024-01-08','2024-01-21',3,12,12),(150,'ABC0392','2024-02-08',2021,220,'Vehicle 039 description',NULL,4900,'2024-01-09','2024-01-22',4,13,13),(151,'ABC0402','2024-02-09',2022,225,'Vehicle 040 description',NULL,5000,'2024-01-10','2024-01-23',5,14,14),(162,'ABC0412','2024-02-10',2023,230,'Vehicle 041 description',NULL,5100,'2024-01-11','2024-01-24',1,25,15),(163,'ABC0422','2024-02-11',2021,235,'Vehicle 042 description',NULL,5200,'2024-01-12','2024-01-25',2,26,16),(164,'ABC0432','2024-02-12',2022,240,'Vehicle 043 description',NULL,5300,'2024-01-13','2024-01-26',3,21,17),(165,'ABC0442','2024-02-13',2023,245,'Vehicle 044 description',NULL,5400,'2024-01-14','2024-01-27',4,22,18),(166,'ABC0452','2024-02-14',2021,250,'Vehicle 045 description',NULL,5500,'2024-01-15','2024-01-28',5,23,19),(167,'ABC0462','2024-02-15',2022,255,'Vehicle 046 description',NULL,5600,'2024-01-16','2024-01-29',1,20,20),(168,'ABC0472','2024-02-16',2023,260,'Vehicle 047 description',NULL,5700,'2024-01-17','2024-01-30',2,21,1),(169,'ABC0482','2024-02-17',2021,265,'Vehicle 048 description',NULL,5800,'2024-01-18','2024-01-31',3,22,2),(170,'ABC0492','2024-02-18',2022,270,'Vehicle 049 description',NULL,5900,'2024-01-19','2024-02-01',4,23,3),(171,'ABC0502','2024-02-19',2023,275,'Vehicle 050 description',NULL,6000,'2024-01-20','2024-02-02',5,24,4);
/*!40000 ALTER TABLE `vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehiclebrand`
--

DROP TABLE IF EXISTS `vehiclebrand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehiclebrand` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehiclebrand`
--

LOCK TABLES `vehiclebrand` WRITE;
/*!40000 ALTER TABLE `vehiclebrand` DISABLE KEYS */;
INSERT INTO `vehiclebrand` VALUES (1,'Volvo'),(2,'Caterpillar'),(3,'Daimler'),(4,'Scania'),(5,'Hino'),(6,'Mack'),(7,'Isuzu'),(8,'Jeep'),(9,'Land Rover '),(10,'Suzuki'),(11,'Toyota'),(12,'TATA'),(13,'Ashok Leyland');
/*!40000 ALTER TABLE `vehiclebrand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehiclemodel`
--

DROP TABLE IF EXISTS `vehiclemodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehiclemodel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `vehiclebrand_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vehiclemodel_vehiclebrand1_idx` (`vehiclebrand_id`),
  CONSTRAINT `fk_vehiclemodel_vehiclebrand1` FOREIGN KEY (`vehiclebrand_id`) REFERENCES `vehiclebrand` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehiclemodel`
--

LOCK TABLES `vehiclemodel` WRITE;
/*!40000 ALTER TABLE `vehiclemodel` DISABLE KEYS */;
INSERT INTO `vehiclemodel` VALUES (1,'XC90',1),(2,'Bulldozer X1000',2),(3,'Actros 1848',3),(4,'R500',4),(5,'Poncho',5),(6,'Granite',6),(7,'NPR',7),(8,'Wrangler',8),(9,'Range Rover Evoque',9),(10,'Swift',10),(11,'Corolla',11),(12,'Indica',12),(13,'Bison',13),(14,'S60',1),(15,'D6R',2),(16,'Arocs 3345',3),(17,'P380',4),(18,'Dutro',5),(19,'Anthem',6),(20,'FTR',7);
/*!40000 ALTER TABLE `vehiclemodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehiclestatus`
--

DROP TABLE IF EXISTS `vehiclestatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehiclestatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehiclestatus`
--

LOCK TABLES `vehiclestatus` WRITE;
/*!40000 ALTER TABLE `vehiclestatus` DISABLE KEYS */;
INSERT INTO `vehiclestatus` VALUES (1,'Busy'),(2,'Broken'),(3,'Loading Truck'),(4,'Maintenace'),(5,'Free');
/*!40000 ALTER TABLE `vehiclestatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicletype`
--

DROP TABLE IF EXISTS `vehicletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicletype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicletype`
--

LOCK TABLES `vehicletype` WRITE;
/*!40000 ALTER TABLE `vehicletype` DISABLE KEYS */;
INSERT INTO `vehicletype` VALUES (1,'Full Size Pickup'),(2,'Mini Pickup'),(3,'Minivan'),(4,'SUV'),(5,'Utility Van'),(6,'Crew Size Pickup'),(7,'Full Size Pickup'),(8,'Mini Bus'),(9,'Minivan'),(10,'Step Van'),(11,'Large Walk In'),(12,'City Delivery'),(13,'Conventional Van'),(14,'Landscape Utility'),(15,'Large Walk In'),(16,'Bucket'),(17,'Beverage'),(18,'Rack'),(19,'Furniture'),(20,'Single Axle Van'),(21,'Stake Body'),(22,'High Profile Semi'),(23,'Home Fuel'),(24,'Medium Semi Tractor'),(25,'TOW'),(26,'Refrigerated Van');
/*!40000 ALTER TABLE `vehicletype` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-03  6:50:03
